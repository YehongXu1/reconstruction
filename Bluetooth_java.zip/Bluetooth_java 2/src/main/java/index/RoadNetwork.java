package index;

import spatialObjects.Coordinate;
import spatialObjects.Edge;
import spatialObjects.Vertex;
import utilities.DistanceFunction;
import utilities.Pair;

import java.io.*;
import java.text.DecimalFormat;
import java.util.*;

import utilities.Utilities;

import static utilities.Utilities.formatDoubles;

public class RoadNetwork {

    private Map<String, Vertex> idToVertex = new HashMap<>();
    private Map<String, Edge> idToEdge = new HashMap<>();
    private Map<String, List<String>> idToPath = new HashMap<>();
    private String pathFile;
    private Map<String, Set<String>> edgeIdToPathIds = new HashMap<>();

    public RoadNetwork(String pathFile) throws IOException {
        this.pathFile = pathFile;
        parsePathFile();
        System.out.println();
    }

    private Map<String, List<Pair<String, Coordinate<Double, Double>>>> readPathFile() throws IOException {
        Map<String, List<Pair<String, Coordinate<Double, Double>>>> paths = new HashMap<>();

        BufferedReader br = new BufferedReader(new FileReader(this.pathFile));
        String line = br.readLine();

        while (line != null) {
            String pathId = Arrays.asList(line.split("\\|")).get(0);
            String[] ll = Arrays.asList(line.split("\\|")).get(1).split(",");

            List<Pair<String, Coordinate<Double, Double>>> points = new ArrayList<>();

            for (String item : ll) {
                String vId = Arrays.asList(item.split("\\s")).get(0);
                double lat = formatDoubles(Double.parseDouble(Arrays.asList(item.split("\\s")).get(2)));
                double lon = formatDoubles(Double.parseDouble(Arrays.asList(item.split("\\s")).get(1)));
                Pair<String, Coordinate<Double, Double>> idToVer = new Pair<>(vId, new Coordinate<>(lat, lon));
                points.add(idToVer);
            }
            paths.put(pathId, points);
            line = br.readLine();
        }
        br.close();
        return paths;
    }

    private void parsePathFile() throws IOException {
        Map<String, List<Pair<String, Coordinate<Double, Double>>>> idToPath = readPathFile();

        for (Map.Entry<String, List<Pair<String, Coordinate<Double, Double>>>> entry : idToPath.entrySet()) {

            String pathId = entry.getKey();
            List<String> verticesInPath = new ArrayList<>();

            List<Pair<String, Coordinate<Double, Double>>> path = entry.getValue();
            verticesInPath.add(path.get(0)._1());


            for (int i = 1; i < path.size(); i++) {
                verticesInPath.add(path.get(i)._1());

                Pair<String, Coordinate<Double, Double>> startNode = path.get(i - 1);
                Pair<String, Coordinate<Double, Double>> endNode = path.get(i);

                if (startNode != null && !endNode.equals(startNode)) {

                    List<Coordinate<Double, Double>> intermediateNodes = new ArrayList<>(); // not including s and t nodes
//                    interpolate(startNode._2().getLat(), startNode._2().getLon(),
//                            endNode._2().getLat(), endNode._2().getLon(), 0.05, intermediateNodes);

                    Vertex startVer = getVertex(startNode);
                    Vertex endVer = getVertex(endNode);

                    if (intermediateNodes.size() == 0) {
                        startVer.addNeighbours(endVer.getId());
                        endVer.addNeighbours(startVer.getId());
                        String edgeId = startVer.getId() + "|" + endVer.getId();
                        idToEdge.put(edgeId, new Edge(startVer, endVer, edgeId));

                        if (edgeIdToPathIds.get(edgeId) == null) {
                            Set<String> set = new HashSet<>();
                            set.add(pathId);
                            edgeIdToPathIds.put(edgeId, set);
                        }
                        else {
                            edgeIdToPathIds.get(edgeId).add(pathId);
                        }

//                        idToEdge.put(endVer.getId() + "|" + startVer.getId(),
//                                new Edge(endVer, startVer, endVer.getId() + "|" + startVer.getId()));

                    }
//                    else {
//                        Vertex firstInterV = getVertex(startNode._1() + "|" + endNode._1() + "|" + 1, intermediateNodes.get(0));
//                        firstInterV.addNeighbours(startVer.getId());
//                        startVer.addNeighbours(firstInterV.getId());
//                        idToEdge.put(startVer.getId() + "|" + firstInterV.getId(), new Edge(startVer, firstInterV));
//
//                        Vertex lastInterV = getVertex(startNode._1() + "|" + endNode._1() + "|" + intermediateNodes.size(),
//                                intermediateNodes.get(intermediateNodes.size() - 1));
//                        lastInterV.addNeighbours(endVer.getId());
//                        endVer.addNeighbours(lastInterV.getId());
//                        idToEdge.put(lastInterV.getId() + "|" + endVer.getId(), new Edge(lastInterV, endVer));
//
//                        idToVertex.put(lastInterV.getId(), lastInterV);
//                        if (intermediateNodes.size() > 1) {
//                            for (int j = 1; j < intermediateNodes.size(); j++) {
//                                Vertex preV = getVertex(startNode._1() + "|" + endNode._1() + "|" + j, intermediateNodes.get(j - 1));
//                                Vertex V = getVertex(startNode._1() + "|" + endNode._1() + "|" + (j + 1), intermediateNodes.get(j));
//
//                                preV.addNeighbours(V.getId());
//                                V.addNeighbours(preV.getId());
//                                idToEdge.put(preV.getId() + "|" + V.getId(), new Edge(preV, V));
//                            }
//                        }
//                    }
                }
            }
            this.idToPath.put(pathId, verticesInPath);
        }
    }

    public Map<String, Vertex> getVertex() {
        return this.idToVertex;
    }


    public Map<String, Edge> getEdges() {
        return this.idToEdge;
    }

    private void interpolate(double lat1_, double lng1_, double lat2_, double lng2_,
                             double intervalLenKm, List<Coordinate<Double, Double>> intermediatePoints) {
        double dist = DistanceFunction.pointToPointDistance(lat1_, lng1_, lat2_, lng2_);
        if (dist > intervalLenKm) {
            Coordinate<Double, Double> intermediatePoint = DistanceFunction.intermediatePoint(lat1_, lng1_, lat2_, lng2_, intervalLenKm);

            intermediatePoints.add(intermediatePoint);

            interpolate(intermediatePoint.getLat(), intermediatePoint.getLon(), lat2_, lng2_, intervalLenKm, intermediatePoints);
        }
    }

    private Vertex getVertex(Pair<String, Coordinate<Double, Double>> pair) {

        if (idToVertex.containsKey(pair._1())) {
            return idToVertex.get(pair._1());
        } else {
            Vertex v = new Vertex(pair._1(), pair._2());
            idToVertex.put(pair._1(), v);
            return v;
        }
    }

    public Map<String, Set<String>> getEdgeIdToPathIds() {
        return edgeIdToPathIds;
    }

    public static void main(String[] args) throws IOException {
        String edges = "/Users/xyh/Desktop/edges.txt";
//        String edge_Path = "/Users/xyh/Desktop/experimental results/edges_Brisbane.txt";
        String edge_Path = "/Users/xyh/Documents/Bluetooth/data/input/map/edges_Brisbane.txt";
//        String edge_Path = "/Users/xyh/Desktop/test_gt5.txt/edges_Brisbane.txt";
        RoadNetwork roadNetwork = new RoadNetwork(edge_Path);
        BufferedWriter bw = new BufferedWriter(new FileWriter(edges));

        String edgeId = roadNetwork.getEdges().get("21592020|47410563").getId();
        System.out.println(edgeId);

        for (Map.Entry<String, Edge> stringEdgeEntry : roadNetwork.getEdges().entrySet()) {
            bw.write(stringEdgeEntry.getKey()+","+stringEdgeEntry.getValue().toString()+"\n");
        }
        bw.flush();
        bw.close();


//            String groundTruth = "/Users/xyh/Desktop/statistics/ground_truths.txt";
//            String groundTruthWrite = "/Users/xyh/Desktop/statistics/ground_truths_edges.txt";
//            RoadNetwork roadNetwork = new RoadNetwork(edge_Path);
//
//            BufferedReader br = new BufferedReader(new FileReader(groundTruth));
//            BufferedWriter bw = new BufferedWriter(new FileWriter(groundTruthWrite));
//
//            String line = br.readLine();
//
//            while (line != null) {
//                String id = Arrays.asList(line.split(";")).get(0);
//                String[] paths = Arrays.asList(line.split(";")).get(1).strip().split("\\s");
//
//                StringBuilder sb = new StringBuilder(id); sb.append(";");
//                System.out.println("~~~~~~~~~~~~~");
//                System.out.println(id +" "+paths[0]);
//                String prevVer = roadNetwork.idToPath.get(paths[0]).get(0); // first vertex of this ground truth
//                for (String path : paths) {
//                    System.out.println(path);
//                    List<String> verticesInPath = roadNetwork.idToPath.get(path);
//                    for (String currVer:verticesInPath) {
//                        if (prevVer.equals(currVer)) continue;
//                        sb.append(prevVer);
//                        sb.append("|");
//                        sb.append(currVer);
//                        sb.append(" ");
//
//                        prevVer = currVer;
//                    }
//
//                }
//                bw.write(sb.toString()+"\n");
//                line = br.readLine();
//            }
//            bw.flush();
//            bw.close();
    }
}


