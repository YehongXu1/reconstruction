package index;


//import org.apache.log4j.Logger;

import spatialObjects.Coordinate;
import spatialObjects.Edge;
import spatialObjects.PointMatch;
import spatialObjects.Vertex;
//import util.function.DistanceFunction;
//import util.object.roadnetwork.RoadNetworkGraph;
//import util.object.roadnetwork.RoadNode;
//import util.object.roadnetwork.RoadWay;
//import util.object.spatialobject.Point;
//import util.object.structure.Pair;
//import util.object.structure.PointMatch;
//import util.settings.BaseProperty;
import utilities.*;

import java.io.IOException;
import java.io.Serializable;
import java.util.*;

/**
 * Graph object used in Dijkstra shortest path search algorithm.
 */
public class RoutingGraph implements Serializable {

    //    private static final Logger LOG = Logger.getLogger(RoutingGraph.class);
    private HashMap<Integer, String> edgeIndex2RoadID = new HashMap<>();    // the mapping between the mini edge index and its corresponding
    // roadway id and serial number, format: (index,roadID,serialNum), serialNum starts from 0
    private HashMap<String, Integer> endPointLoc2EdgeIndex = new LinkedHashMap<>();  // find the mini edge index using the coordinates and
    // road way id, format: (x1_x2,y1_y2,id)
    private HashMap<Pair<Integer, Integer>, Integer> endPointsIndex2EdgeIndex = new HashMap<>();  // find the mini edge index given the end point indices
    // and its distance to the current edge
    private RoutingVertex[] vertices;
    private RoutingEdge[] routingEdges;

    /**
     * Create routing graph for map-matching.
     *
     * @param roadNetwork The map used to build routing graph.
     */
    public RoutingGraph(RoadNetwork roadNetwork) {
        // insert the road node into node list
        HashMap<String, Integer> nodeID2Index = new HashMap<>();
        HashMap<Integer, Coordinate<Double, Double>> vertexID2Loc = new LinkedHashMap<>();
        // the size of the vertex list and the current index of the new vertex
        int vertexIndex = 0;
        for (Map.Entry<String, Vertex> idToNode : roadNetwork.getVertex().entrySet()) {
            if (nodeID2Index.containsKey(idToNode.getValue().getId()))
                throw new IllegalArgumentException("Road node ID already exists: " + idToNode.getValue().getId());
            nodeID2Index.put(idToNode.getValue().getId(), vertexIndex);
            vertexID2Loc.put(vertexIndex, idToNode.getValue().getCoordinate());
            vertexIndex++;
        }

        List<RoutingEdge> routingEdgeList = new ArrayList<>();
        int edgeIndex = 0;
        for (Map.Entry<String, Edge> idToEdge : roadNetwork.getEdges().entrySet()) {

            Vertex startNode = idToEdge.getValue().getSource();
            Vertex endNode = idToEdge.getValue().getTarget();
            edgeIndex2RoadID.put(edgeIndex, idToEdge.getKey());    // sn from 0 to way.getNodes.size()-2
            if (endPointLoc2EdgeIndex.containsKey(idToEdge.getKey())) {
                throw new IllegalArgumentException("The same start and end nodes generate multiple roads: " + edgeIndex);
            }
            endPointLoc2EdgeIndex.put(idToEdge.getKey(), edgeIndex);
            int startIndex = nodeID2Index.get(startNode.getId());
            int endIndex = nodeID2Index.get(endNode.getId());
            Pair<Integer, Integer> endPointIndices = new Pair<>(startIndex, endIndex);
            if (!endPointsIndex2EdgeIndex.containsKey(endPointIndices)) {
//                throw new IllegalArgumentException("The same start and end node id refer to multiple roads: " + edgeIndex);
                endPointsIndex2EdgeIndex.put(endPointIndices, edgeIndex);
                RoutingEdge currRoutingEdge = new RoutingEdge(edgeIndex, startIndex, endIndex,
                        DistanceFunction.pointToPointDistance(
                                startNode.getCoordinate().getLat(), startNode.getCoordinate().getLon(),
                                endNode.getCoordinate().getLat(), endNode.getCoordinate().getLon()));
                routingEdgeList.add(currRoutingEdge);
            }
            edgeIndex++;
        }
        this.routingEdges = new RoutingEdge[routingEdgeList.size()];
        for (int i = 0; i < routingEdgeList.size(); i++) {
            RoutingEdge currRoutingEdge = routingEdgeList.get(i);
            if (currRoutingEdge.getIndex() != i)
                throw new IllegalArgumentException("The current routing edge id is inconsistent: " + currRoutingEdge.getIndex() + "," + i + ".");
            this.routingEdges[i] = currRoutingEdge;
        }

        // create all vertices ready to be updated with the routingEdges
        this.vertices = new RoutingVertex[vertexIndex];
        for (int n = 0; n < vertexIndex; n++) {
            this.vertices[n] = new RoutingVertex();
            this.vertices[n].setIndex(n);
            this.vertices[n].setVertexPoint(vertexID2Loc.get(n));
        }

        // add all the routingEdges to the vertices, each edge added to only from vertices
        for (RoutingEdge routingEdge : this.routingEdges) {
            this.vertices[routingEdge.getFromNodeIndex()].getOutGoingRoutingEdges().add(routingEdge);
        }

    }

    /**
     * Given a source match point and a set of destination points, the function calculate the shortest path to each destination and their
     * distance using A* algorithm.
     *
     * @param source         The source match point and its segment.
     * @param pointList      The destination match point list.
     * @param referencePoint The point used to calculate heuristic reference distance.
     * @param maxSearchDist  The maximum search range where shortest path search terminates.
     * @return List of results which contain distance and shortest path. distance = Double.POSITIVE_INFINITY and path is empty if not
     * reachable within maxSearchDist.
     */
    public List<Pair<Double, List<String>>> calculateOneToNAStarSP(
            PointMatch source, List<PointMatch> pointList, Coordinate<Double, Double> referencePoint, double maxSearchDist) {

        double[] distance = new double[pointList.size()];   // the distance to every destination
        List<List<String>> path = new ArrayList<>(pointList.size());     // the path to every destination
        HashMap<Integer, Integer> parent = new HashMap<>();        // the parent of each vertex, used during A* traversal
        HashMap<Integer, Double> vertexDistFromSource = new HashMap<>();    // the distance from the vertex to the source node
        HashSet<Integer> vertexVisited = new HashSet<>();        // set of vertices visited
        List<Pair<Double, List<String>>> result;

        Arrays.fill(distance, Double.POSITIVE_INFINITY);
        for (int i = 0; i < pointList.size(); i++) {
            path.add(new ArrayList<>());
        }
        // the variables have been initialized during the last calculation. Start the process right away
        HashMap<Integer, Set<Integer>> vertexID2DestIndexSet = new HashMap<>();        // all destinations that requires A* search,
        // (destination vertex ID and destination index in pointList)


        // if source point doesn't exist, return infinity to all distances
//		String sourceLocID = source.getMatchedSegment().x1() + "_" + source.getMatchedSegment().y1() + "," + source.getMatchedSegment()
//				.x2() + "_" + source.getMatchedSegment().y2() + "," + source.getRoadID();

        String sourceLocID = source.getRoadID().strip();

        if (!this.endPointLoc2EdgeIndex.containsKey(sourceLocID)) {
//            LOG.error("Shortest distance calculation failed: Source node is not found: " + sourceLocID);
            result = new ArrayList<>(resultOutput(distance, path));
            return result;
        }

        // the start node of the current A* rotation
        int startEdgeIndex = endPointLoc2EdgeIndex.get(sourceLocID);
        String startRoadID = edgeIndex2RoadID.get(startEdgeIndex);
        int startNodeIndex = this.routingEdges[startEdgeIndex].getToNodeIndex();
        double sourceDistance = DistanceFunction.pointToPointDistance(source.getMatchedPoint(), source.getMatchedSegment().getEndNode());
        // attach all destination points to the graph
        int destPointCount = pointList.size();
        for (int i = 0; i < pointList.size(); i++) {

//			String destLocID = pointList.get(i).getMatchedSegment().x1() + "_" + pointList.get(i).getMatchedSegment().y1() + "," +
//					pointList.get(i).getMatchedSegment().x2() + "_" + pointList.get(i).getMatchedSegment().y2() + "," + pointList.get(i)
//					.getRoadID();
            String destLocID = pointList.get(i).getRoadID().strip();

            if (!endPointLoc2EdgeIndex.containsKey(destLocID)) {
//                LOG.error("Destination node is not found: " + destLocID);
                destPointCount--;
//            } else if (pointList.get(i).getMatchPoint().equals2D(pointList.get(i).getMatchedSegment().p1())) {
//                destPointCount--;
            } else {
                int destEdgeIndex = endPointLoc2EdgeIndex.get(destLocID);
                String destRoadID = edgeIndex2RoadID.get(destEdgeIndex);
                if (destEdgeIndex == startEdgeIndex &&
                        DistanceFunction.pointToPointDistance(source.getMatchedPoint(), source.getMatchedSegment().getEndNode()) >=
                                DistanceFunction.pointToPointDistance(pointList.get(i).getMatchedPoint(), pointList.get(i).getMatchedSegment().getEndNode())) {    // two segments
                    // refer to the same mini edge and they are in the right order
                    if (!startRoadID.equals(destRoadID))
                        throw new IllegalArgumentException("Same mini edge occurred in different roads: " + destEdgeIndex + ".");
                    distance[i] = DistanceFunction.pointToPointDistance(source.getMatchedPoint(), pointList.get(i).getMatchedPoint());
                    path.get(i).add(destRoadID);
                    destPointCount--;
                } else if (vertexID2DestIndexSet.containsKey(this.routingEdges[destEdgeIndex].getFromNodeIndex())) {
                    vertexID2DestIndexSet.get(this.routingEdges[destEdgeIndex].getFromNodeIndex()).add(i);
                } else {
                    Set<Integer> indexSet = new HashSet<>();
                    indexSet.add(i);
                    vertexID2DestIndexSet.put(this.routingEdges[destEdgeIndex].getFromNodeIndex(), indexSet);
                }
            }
        }

        // the rest of the destinations are on different mini edges, now set the end of the current mini edge as start vertex
        if (destPointCount > 0) {
            // A* start node
            double hDist;
            double distFromSource;
            double searchDist;
            int nextVertexIndex;
            vertexDistFromSource.put(startNodeIndex, 0d);
            parent.put(startNodeIndex, startNodeIndex);
            MinPriorityQueue minHeap = new MinPriorityQueue();
            int currIndex = startNodeIndex;

            // visit every node
            while (currIndex != -1 && vertexDistFromSource.get(currIndex) < (maxSearchDist - sourceDistance)) {
                // loop around the edges of current node
//				LOG.info(vertexDistFromSource.get(currIndex));
                List<RoutingEdge> currentOutgoingRoutingEdges = vertices[currIndex].getOutGoingRoutingEdges();
                for (RoutingEdge currEdge : currentOutgoingRoutingEdges) {
                    nextVertexIndex = currEdge.getToNodeIndex();
                    distFromSource = vertexDistFromSource.get(currIndex) + currEdge.getLength();
                    hDist = DistanceFunction.pointToPointDistance(this.vertices[nextVertexIndex].getVertexPoint(), referencePoint);
                    searchDist = distFromSource + hDist;
                    if (!vertexVisited.contains(nextVertexIndex) && minHeap.decreaseKey(nextVertexIndex, searchDist)
                            && (!vertexDistFromSource.containsKey(nextVertexIndex) || vertexDistFromSource.get(nextVertexIndex) > distFromSource)) {
                        vertexDistFromSource.put(nextVertexIndex, distFromSource);
                        parent.put(nextVertexIndex, currIndex);
                    }
                }
                // all neighbours checked so node visited
                vertexVisited.add(currIndex);
                 if (vertexID2DestIndexSet.containsKey(currIndex)) {
                    for (Integer i : vertexID2DestIndexSet.get(currIndex)) {
                        destPointCount--;
                        distance[i] = vertexDistFromSource.get(currIndex);
                        distance[i] += sourceDistance;
                        distance[i] += DistanceFunction.pointToPointDistance(pointList.get(i).getMatchedSegment().getStartNode(), pointList.get(i).getMatchedPoint());
                        if (sourceDistance != 0)
                            path.get(i).add(startRoadID);
                        path.get(i).addAll(findPath(currIndex, parent));
                        if (path.get(i).size() > 1 && path.get(i).get(0).equals(path.get(i).get(1)))
                            path.get(i).remove(1);    // remove the duplicated start road ID
                        String lastRoadID = pointList.get(i).getRoadID().strip();
                        if (!pointList.get(i).getMatchedSegment().getStartNode().equals(pointList.get(i).getMatchedPoint())) {
                            if (path.get(i).isEmpty() || !lastRoadID.equals(path.get(i).get(path.get(i).size() - 1)))
                                path.get(i).add(lastRoadID);
                        }
                    }
                }
                if (destPointCount == 0) {
                    result = new ArrayList<>(resultOutput(distance, path));
                    return result;
                }
                // next node must be with shortest distance
                currIndex = minHeap.extractMin();
            }
//            LOG.info((pointList.size() - destPointCount) + "/" + pointList.size() + "distances are found.");
            result = new ArrayList<>(resultOutput(distance, path));
            return result;
        }
        result = new ArrayList<>(resultOutput(distance, path));
        return result;
    }

    private List<String> findPath(int index, HashMap<Integer, Integer> parent) {
        Set<String> roadIDSet = new LinkedHashSet<>();
        while (parent.get(index) != index) {
//            if (parent.get(index) == -1)
//                LOG.error("Road path is broken!");
            Pair<Integer, Integer> currentSegment = new Pair<>(parent.get(index), index);
            int edgeID = endPointsIndex2EdgeIndex.get(currentSegment);
            roadIDSet.add(edgeIndex2RoadID.get(edgeID));
            index = parent.get(index);
        }
        List<String> roadIDList = new ArrayList<>(roadIDSet);
        Collections.reverse(roadIDList);
        return roadIDList;
    }

    private List<Pair<Double, List<String>>> resultOutput(double[] distance, List<List<String>> path) {
        List<Pair<Double, List<String>>> result = new ArrayList<>();
        for (int i = 0; i < distance.length; i++) {
            result.add(new Pair<>(distance[i], path.get(i)));
        }
        return result;
    }

    public static void main(String[] args) throws IOException {
        String edge_Path = "/Users/xyh/Documents/Bluetooth/Bluetooth-visualization/Data/input/edges_Brisbane.txt";
        RoutingGraph g = new RoutingGraph(new RoadNetwork(edge_Path));
        Set<String> keys = g.endPointLoc2EdgeIndex.keySet();
    }
}