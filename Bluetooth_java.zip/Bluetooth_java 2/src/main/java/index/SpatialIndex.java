package index;

import spatialObjects.*;
import com.github.davidmoten.grumpy.core.Position;
import com.github.davidmoten.rtree.Entry;
import com.github.davidmoten.rtree.RTree;
import com.github.davidmoten.rtree.geometry.*;
import rx.Observable;
import rx.functions.Func1;
import utilities.DistanceFunction;

import java.util.*;

import static utilities.Utilities.formatDoubles;

public class SpatialIndex {

    private RTree<String, Line> rTree;
    private RoadNetwork roadNetwork;

    public SpatialIndex(RoadNetwork roadNetwork) {
        this.roadNetwork = roadNetwork;
        this.rTree = buildRtree();
    }

    public SpatialIndex(RTree<String, Line> rTree) {
        this.rTree = rTree;
    }

    private RTree<String, Line> buildRtree() {

        RTree<String, Line> rTree = RTree.star().create();
        Map<String, Edge> edgeMap = roadNetwork.getEdges();

        for (Map.Entry<String, Edge> entry : edgeMap.entrySet()) {

            Line line = Geometries.line(
                    entry.getValue().getSource().getCoordinate().getLon(), entry.getValue().getSource().getCoordinate().getLat(),
                    entry.getValue().getTarget().getCoordinate().getLon(), entry.getValue().getTarget().getCoordinate().getLat());

            rTree = rTree.add(entry.getValue().getId(), line);
        }
        return rTree;
    }

    // find k nearest edges
    public String nearestEdge(Double lat, Double lng) {
        List<Entry<String, Line>> result = search(lat, lng, 1);

        double minDist = Double.POSITIVE_INFINITY;
        String closest = null;
        for (Entry<String, Line> entry : result) {
            Line line = entry.geometry();
            double dist = DistanceFunction.pointClosestDistanceFromSegment(line.y1(), line.x1(), line.y2(), line.x2(), lat, lng);

            if (dist < minDist) {
                minDist = dist;
                closest = entry.value();
            }
        }
        return closest;
    }

    // return intersected lines
    public List<Entry<String, Line>> search(double lat, double lon, final double distanceKm) {
        return privateSearch(lat, lon, distanceKm).toList().toBlocking().single();
    }

    private Observable<Entry<String, Line>> privateSearch(double lat, double lon, final double distanceKm) {
        // First we need to calculate an enclosing lat long rectangle for this
        // distance then we refine on the exact distance
        final Position from = Position.create(lat, lon);
        Rectangle bounds = createBounds(from, distanceKm);
        return rTree
                // do the first search using the bounds (using L2 distance)
                .search(bounds)
                // refine using the exact distance
                .filter(new Func1<Entry<String, Line>, Boolean>() {
                    @Override
                    public Boolean call(Entry<String, Line> entry) {
                        Line p = entry.geometry();
                        double distance = DistanceFunction.pointClosestDistanceFromSegment(p.y1(), p.x1(), p.y2(), p.x2(), lat, lon);

//                        if (entry.value().strip().equals("2580429659|1546620203") ||
//                                entry.value().strip().equals("1546620203|5905492609")||
//                                entry.value().strip().equals("5905492609|21592020")||
//                                entry.value().strip().equals("21592020|474105630")||
//                                entry.value().strip().equals("47410563|1449286039")) {
//                            System.out.println(entry.value() + ": " + distance + " to [" + lat + "," + lon + "], ");
//                        }
                        return distance < distanceKm;
                    }
                });
    }


    private Observable<Entry<String, Line>> privateSearchInRange(double lat, double lon, double distance) {
        final Position from = Position.create(lat, lon);
        Rectangle bounds = createBounds(from, distance);
        return rTree
                // do the first search using the bounds (using L2 distance)
                .search(bounds)
                // refine using the exact distance
                .filter(new Func1<Entry<String, Line>, Boolean>() {
                    @Override
                    public Boolean call(Entry<String, Line> entry) {
                        Line p = entry.geometry();
                        double closestDistance = DistanceFunction.pointClosestDistanceFromSegment(p.y1(), p.x1(), p.y2(), p.x2(), lat, lon);
                        double longestDistance = DistanceFunction.pointLongestDistanceFromSegment(p.y1(), p.x1(), p.y2(), p.x2(), lat, lon);

                        return longestDistance >= distance && closestDistance <= distance;
                    }
                });
    }

    public List<Entry<String, Line>> searchInRange(double lat, double lon, double distance) {
        return privateSearchInRange(lat, lon, distance).toList().toBlocking().single();
    }

    private static Rectangle createBounds(final Position from, final double distanceKm) {
        // this calculates a pretty accurate bounding box. Depending on the
        // performance you require you wouldn't have to be this accurate because
        // accuracy is enforced later
        Position north = from.predict(distanceKm, 0);
        Position south = from.predict(distanceKm, 180);
        Position east = from.predict(distanceKm, 90);
        Position west = from.predict(distanceKm, 270);

        return Geometries.rectangle(west.getLon(), south.getLat(), east.getLon(), north.getLat());
    }

    public List<PointMatch> searchNeighbours(Coordinate<Double, Double> from, double radiusKm) {
        List<Entry<String, Line>> results = search(from.getLat(), from.getLon(), radiusKm);
        List<PointMatch> neighbours = new ArrayList<>();

        for (Entry<String, Line> pair : results) {
            Coordinate<Double, Double> startNode = new Coordinate<>(pair.geometry().y1(), pair.geometry().x1());
            Coordinate<Double, Double> endNode = new Coordinate<>(pair.geometry().y2(), pair.geometry().x2());

            Coordinate<Double, Double> closestPoint = DistanceFunction.closestPointOnSegment(startNode, endNode, from);
            Segment sg = new Segment(formatDoubles(startNode.getLat()), formatDoubles(startNode.getLon()),
                    formatDoubles(endNode.getLat()), formatDoubles(endNode.getLon()));

            neighbours.add(new PointMatch(closestPoint, sg, pair.value()));
        }
        return neighbours;
    }


    public RTree<String, Line> getRTree() {
        return this.rTree;
    }
}
