package index;

import com.github.davidmoten.rtree.Entry;
import com.github.davidmoten.rtree.geometry.Geometry;
import com.github.davidmoten.rtree.geometry.Line;
import hmm.StateSample;
import spatialObjects.Coordinate;

import java.io.*;
import java.nio.Buffer;
import java.util.*;

public class Station {
    private String stationId;
    private double latitude;
    private double longitude;
    private List<String> coveredEdges;
    private List<String> coveredPaths;

    private Station(String stationId, double latitude, double longitude, List<String> coveredEdges, List<String> coveredPaths) {
        this.stationId = stationId;
        this.latitude = latitude;
        this.longitude = longitude;
        this.coveredPaths = coveredPaths;
        this.coveredEdges = coveredEdges;
    }

    public static Map<String, Station> iniStations(String stationPath, RoadNetwork roadNetwork, double radius) throws IOException {

        BufferedWriter bw = new BufferedWriter(new FileWriter("/Users/xyh/Desktop/statistics/stations.txt"));
        SpatialIndex spatialIndex = new SpatialIndex(roadNetwork);

        BufferedReader br = new BufferedReader(new FileReader(stationPath));

        String line = br.readLine();

        Map<String, Station> stationLocation = new HashMap<>();

        while (line != null) {
            String stationId = Arrays.asList(line.split("\\s")).get(0);

            double lat = Double.parseDouble(Arrays.asList(line.split("\\s")).get(2));
            double lon = Double.parseDouble(Arrays.asList(line.split("\\s")).get(1));

            List<String> coveredPaths = new ArrayList<>();
            List<String> coveredEdges = new ArrayList<>();

            List<Entry<String, Line>> lines = spatialIndex.search(lat, lon, radius);
            for (Entry<String, Line> edge : lines) {
                coveredEdges.add(edge.value());
                String path = Arrays.asList(edge.value().split("\\|")).get(0);
                if (!coveredPaths.contains(path)) {
                    coveredPaths.add(path);
                }
            }
            stationLocation.put(stationId,
                    new Station(stationId, lat, lon, coveredEdges, coveredPaths));

            line = br.readLine();
            StringBuilder sb = new StringBuilder();
            for (String coveredEdge : coveredEdges) {
                sb.append(coveredEdge);
                sb.append(",");
            }

            bw.write(stationId+" "+lat+" "+lon+" "+coveredEdges.size()+" "+sb.toString()+"\n");
        }
        bw.flush();
        bw.close();
        br.close();
        return stationLocation;
    }

    public String getStationId() {
        return stationId;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public Coordinate<Double, Double> getLocation() {
        return new Coordinate<>(latitude, longitude);
    }

    public List<String> getCoveredPaths(){
        return coveredPaths;
    }

    public List<String> getCoveredEdges(){
        return coveredEdges;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Station station = (Station) o;
        return Double.compare(station.latitude, latitude) == 0 &&
                Double.compare(station.longitude, longitude) == 0 &&
                Objects.equals(stationId, station.stationId) &&
                Objects.equals(coveredPaths, station.coveredPaths) &&
                Objects.equals(coveredEdges, station.coveredEdges);
    }

    @Override
    public int hashCode() {
        return Objects.hash(stationId, latitude, longitude, coveredPaths, coveredEdges);
    }

    public static void main(String[] args) throws IOException {
        String stationPath = "/Users/xyh/Documents/Bluetooth/Bluetooth-visualization/Data/input/station.txt";

        String edge_Path = "/Users/xyh/Documents/Bluetooth/data/input/map/edges_Brisbane.txt";

        String write = "/Users/xyh/Desktop/relevant_paths.txt";
        RoadNetwork roadNetwork = new RoadNetwork(edge_Path);
        Map<String, Station> stringStationMap = Station.iniStations(stationPath, roadNetwork, 0.1);
        SpatialIndex spatialIndex = new SpatialIndex(roadNetwork);
        Set<String> relevantEdges = new HashSet<>();
        for (Map.Entry<String, Station> stringStationEntry : stringStationMap.entrySet()) {
            Station station = stringStationEntry.getValue();
            List<Entry<String, Line>> candidates = spatialIndex.search(station.getLatitude(), station.getLongitude(), 0.4);
            for (Entry<String, Line> candidate : candidates) {
                relevantEdges.add(candidate.value());
            }
        }

        List<String> relevantPaths = new ArrayList<>();
        for (String relevantEdge : relevantEdges) {
            Set<String> pathIds = roadNetwork.getEdgeIdToPathIds().get(relevantEdge);
            relevantPaths.addAll(pathIds);
        }

        System.out.println(relevantPaths.size());

        BufferedWriter bw = new BufferedWriter(new FileWriter(write));
        for (String relevantPath : relevantPaths) {
            bw.write(relevantPath+"\n");
        }
        bw.flush();
        bw.close();
    }
}
