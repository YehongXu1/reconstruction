package transformations;

import observations.Reading;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class TemporalOrderings {

    /**
     * Readings ordered by entered time
     *
     * @param footprint
     */
    public static List<Reading> orderedByEnteredTime(List<Reading> footprint) {
        return footprint;
    }

    public static List<Reading> orderedByDepartTime(List<Reading> footprint) {
        footprint.sort((Reading r1, Reading r2) -> {
            return (int) (r1.getDeparturedTime() - (r2.getDeparturedTime()));
        });
        return footprint;
    }

    public static List<Reading> orderedByMidTime(List<Reading> footprint) {
        footprint.sort((Reading r1, Reading r2) -> {
            return (int) ((r1.getDeparturedTime() + r1.getEnteredTime()) / 2 - (r2.getDeparturedTime() + r2.getEnteredTime()) / 2);
        });
        return footprint;
    }
}
