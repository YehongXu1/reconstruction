package transformations;

import com.github.davidmoten.rtree.Entry;
import com.github.davidmoten.rtree.geometry.Line;
import evaluation.MatchingResult;
import index.RoadNetwork;
import index.SpatialIndex;
import observations.Reading;
import spatialObjects.Coordinate;
import utilities.DistanceFunction;
import utilities.Pair;

import java.io.IOException;
import java.util.*;

import index.SpatialIndex.*;

import javax.swing.*;

import static java.lang.Math.*;
import static utilities.DistanceFunction.findPointOnSegmentGivenDistance;

public class SpatialIdentification {
    private final double radius;
    private final double inquiryCycle;
    private final SpatialIndex spatialIndex;

    public SpatialIdentification(SpatialIndex spatialIndex, double radius, double inquiryCycle) {
        this.inquiryCycle = inquiryCycle;
        this.radius = radius;
        this.spatialIndex = spatialIndex;
    }

    public List<Reading> fixAtStation(List<Reading> footprint) {
        List<Reading> newFootprint = new ArrayList<>();
        for (Reading reading : footprint) {
            Reading newR = new Reading(reading.getEnteredTime(), reading.getDeparturedTime(), reading.getLat(), reading.getLon());
            newR.setFixPosition(reading.getLat(), reading.getLon());
            newFootprint.add(newR);
        }
        return newFootprint;
    }

    private double randomDistance(double innerRadius, double outerRadius) {
        double d;
        if (innerRadius > 0) {
            d = Math.random() * (outerRadius - innerRadius) + innerRadius;
        } else {
            d = Math.random() * outerRadius;
        }
        return d;
    }

    private double randomDistanceGaussianDistribution(double scale) {
        Random r = new Random();
        return Math.abs(r.nextGaussian()) * scale;
    }

    private double randomBearding() {
        Random randomGenerator = new Random();
        return toRadians(randomGenerator.nextInt(361));
    }

    private int randomIdx(int upperBound) {
        Random randomGenerator = new Random();
        return randomGenerator.nextInt(upperBound);
    }

    private Coordinate<Double, Double> randomPointInRange(double clat, double clon, double outerRadius, double innerRadius) {

//        double d = randomDistance(outerRadius, innerRadius);
//        double brng = randomBearding();
//        return DistanceFunction.locFromPointGivenBnrDist(clat, clon, brng, d);

        double distance = randomDistance(innerRadius, outerRadius);
        Coordinate<Double, Double> location = null;
        while (location == null) {
            location = findPhysicalPoint(clat, clon, distance);
            distance = randomDistance(innerRadius, outerRadius);
        }
        return location;
    }

    private Coordinate<Double, Double> randomPointInRange(double clat, double clon, double gaussianScale) {

//        double d = randomDistance(outerRadius, innerRadius);
//        double brng = randomBearding();
//        return DistanceFunction.locFromPointGivenBnrDist(clat, clon, brng, d);

        double distance = randomDistanceGaussianDistribution(gaussianScale);
        Coordinate<Double, Double> location = null;
        while (location == null) {
            location = findPhysicalPoint(clat, clon, distance);
            distance = randomDistanceGaussianDistribution(gaussianScale);
        }
        return location;
    }

    public List<Reading> locationGaussianDistribution(List<Reading> footprint, double gaussianScale) {
        List<Reading> newFootprint = new ArrayList<>();
        for (Reading reading : footprint) {
            Reading newR = new Reading(reading.getEnteredTime(), reading.getDeparturedTime(), reading.getLat(), reading.getLon());
            Coordinate<Double, Double> location = randomPointInRange(reading.getLat(), reading.getLon(), gaussianScale);
            newR.setFixedPosition(location);
            newFootprint.add(newR);
        }

        return newFootprint;
    }


    public List<Reading> locationWithinDistance(List<Reading> footprint, double innerRadius, double outerRadius) {
        List<Reading> newFootprint = new ArrayList<>();
        for (Reading reading : footprint) {
            Reading newR = new Reading(reading.getEnteredTime(), reading.getDeparturedTime(), reading.getLat(), reading.getLon());
            Coordinate<Double, Double> location = randomPointInRange(reading.getLat(), reading.getLon(), innerRadius, outerRadius);
            newR.setFixedPosition(location);
            newFootprint.add(newR);
        }

        return newFootprint;
    }

    private Coordinate<Double, Double> findPhysicalPoint(double lat, double lon, double distance) {
        List<Entry<String, Line>> candidateRoadSegments = spatialIndex.searchInRange(lat, lon, distance);
        int size = candidateRoadSegments.size();
        if (size == 0) return null;
        int randIdx = randomIdx(size);
        Line roadSegment = candidateRoadSegments.get(randIdx).geometry();
        Coordinate<Double, Double> s = new Coordinate<>(roadSegment.y1(), roadSegment.x1());
        Coordinate<Double, Double> t = new Coordinate<>(roadSegment.y2(), roadSegment.x2());
        Coordinate<Double, Double> point = new Coordinate<>(lat, lon);

        List<Coordinate<Double, Double>> potentialPoints = findPointOnSegmentGivenDistance(s, t, point, distance);
        if (potentialPoints.size() == 0) return null;
        int randIdx2 = randomIdx(potentialPoints.size());
        return potentialPoints.get(randIdx2);
    }


    private Pair<Boolean, Double> isSpatialOverlapping(List<Reading> footprint, int cur, int pre) {
        double dist = DistanceFunction.pointToPointDistance(footprint.get(cur).getCoord(), footprint.get(pre).getCoord());
        return new Pair<>(dist < 2 * radius, dist);
    }

    private Pair<Boolean, Double> isTemporalOverlapping(List<Reading> trace, int cur, int pre) {
        Pair<Double, Double> curTimeInterval =
                new Pair<>(trace.get(cur).getEnteredTime() - inquiryCycle, (double) trace.get(cur).getEnteredTime() + trace.get(cur).getDuration());

        Pair<Double, Double> prevTimeInterval =
                new Pair<>(trace.get(pre).getEnteredTime() - inquiryCycle, (double) trace.get(pre).getEnteredTime() + trace.get(pre).getDuration());

        double overlappingTime = curTimeInterval._1() - prevTimeInterval._2();
        return new Pair<>(overlappingTime < 0, overlappingTime);
    }

    private int findLongestReadings(List<Reading> footprint, Pair<Integer, Integer> window) {
        long longestDuration = -1;
        int idx = -1;
        for (int i = window._1(); i <= window._2(); i++) {
            long duration = footprint.get(i).getDeparturedTime() - footprint.get(i).getEnteredTime();
            if (duration > longestDuration) {
                longestDuration = duration;
                idx = i;
            }
        }
        return idx;
    }

    public List<List<Integer>> clusterByTime(List<Reading> footprint, int minSize) {
        List<List<Integer>> overlappingWindows = new ArrayList<>();

        List<Integer> window = new ArrayList<>();

        for (int i = 1; i < footprint.size(); i++) {
            if (window.size() == 0) {
                // a new overlapping window
                if (isTemporalOverlapping(footprint, i, i - 1)._1()) {
                    window.add(i);
                    window.add(i-1);
                }
            } else {
                List<Integer> newWindow = new ArrayList<>();
                for (int pre : window) {
                    if (isTemporalOverlapping(footprint, i, pre)._1())
                        newWindow.add(pre);
                }
                if (newWindow.size() == window.size()) {
                    window.add(i);
                } else {
                    // trace[i] does not overlap with all readings in cur window
                    if (window.size() >= minSize) {
                        overlappingWindows.add(window);
                    }
                    newWindow.add(i);
                    window = newWindow;
                }
            }
        }

        if (window.size() >= minSize) {
            overlappingWindows.add(window);
        }

        return overlappingWindows;
    }

    public List<List<Integer>> clusterBySpace(List<Reading> footprint, int minSize) {
        List<List<Integer>> overlappingWindows = new ArrayList<>();

        List<Integer> window = new ArrayList<>();

        for (int i = 1; i < footprint.size(); i++) {
            if (window.size() == 0) {
                // a new overlapping window
                if (isSpatialOverlapping(footprint, i, i - 1)._1()) {
                    window.add(i);
                    window.add(i-1);
                }
            } else {
                List<Integer> newWindow = new ArrayList<>();
                for (int pre : window) {
                    if (isSpatialOverlapping(footprint, i, pre)._1())
                        newWindow.add(pre);
                }
                if (newWindow.size() == window.size()) {
                    window.add(i);
                } else {
                    // trace[i] does not overlap with all readings in cur window
                    if (window.size() >= minSize) {
                        overlappingWindows.add(window);
                    }
                    newWindow.add(i);
                    window = newWindow;
                }
            }
        }

        if (window.size() >= minSize) {
            overlappingWindows.add(window);
        }

        return overlappingWindows;
    }

    public List<List<Integer>> clusterBySpaceNTime(List<Reading> footprint, int minSize) {
        List<List<Integer>> overlappingWindows = new ArrayList<>();

        List<Integer> window = new ArrayList<>();

        for (int i = 1; i < footprint.size(); i++) {
            if (window.size() == 0) {
                // a new overlapping window
                if (isSpatialOverlapping(footprint, i, i - 1)._1() && isTemporalOverlapping(footprint, i, i-1)._1()) {
                    window.add(i);
                    window.add(i-1);
                }

            } else {
                List<Integer> newWindow = new ArrayList<>();
                for (int pre : window) {
                    if (isSpatialOverlapping(footprint, i, pre)._1()&& isTemporalOverlapping(footprint, i, i-1)._1())
                        newWindow.add(pre);
                }
                if (newWindow.size() == window.size()) {
                    window.add(i);
                } else {
                    // trace[i] does not overlap with all readings in cur window
                    if (window.size() >= minSize) {
                        overlappingWindows.add(window);
                    }
                    newWindow.add(i);
                    window = newWindow;
                }
            }
        }

        if (window.size() >= minSize) {
            overlappingWindows.add(window);
        }

        return overlappingWindows;

    }

    public List<Pair<Integer, Integer>> detectOverlappingRegion2InSpace(List<Reading> trace, int minSize) {
        List<Pair<Integer, Integer>> overlappingWindows = new ArrayList<>();

        int windowStart = 0;
        int windowEnd = 0;

        for (int i = 1; i < trace.size(); i++) {
            int inspectIdx = windowStart;
            while (inspectIdx <= windowEnd) {
                if (!isSpatialOverlapping(trace, i, inspectIdx)._1()) break;
                inspectIdx += 1;
            }
            if (inspectIdx == windowEnd + 1) {
                // overlap with every reading in this window
                windowEnd = i;
            } else {
                if (windowEnd - windowStart + 1 >= minSize) {
                    overlappingWindows.add(new Pair<>(windowStart, windowEnd));
                }
                windowStart = i;
                windowEnd = i;
            }
        }

        if (windowEnd - windowStart + 1 > minSize) {
            overlappingWindows.add(new Pair<>(windowStart, windowEnd));
        }
        return overlappingWindows;
    }


    public List<Reading> clusterUsingCentroid(List<Reading> footprint, List<List<Integer>> windows) {
        List<Reading> newFootprint = new ArrayList<>();
        Set<Integer> filteredReadings = new HashSet<>();
        Set<Integer> centroids = new HashSet<>();

        for (List<Integer> window : windows) {
            filteredReadings.addAll(window);

            int centroidIdx = findCentroid(footprint, window);
//            int centroidIdx = (window._1() + window._2()) % 2 == 0 ? (window._1() + window._2()) / 2 : (window._1() + window._2() + 1) / 2;
            centroids.add(centroidIdx);
        }

        for (int i = 0; i < footprint.size(); i++) {
            if (filteredReadings.contains(i) && !centroids.contains(i)) continue;
            Reading newR = new Reading(
                    footprint.get(i).getEnteredTime(), footprint.get(i).getDeparturedTime(), footprint.get(i).getLat(), footprint.get(i).getLon());
            newR.setFixPosition(footprint.get(i).getLat(), footprint.get(i).getLon());
            newFootprint.add(newR);
        }

        // ensure the last reading is included
        if (!newFootprint.get(newFootprint.size() - 1).equals(footprint.get(footprint.size() - 1))) {
            Reading newR = new Reading(
                    footprint.get(footprint.size() - 1).getEnteredTime(), footprint.get(footprint.size() - 1).getDeparturedTime(),
                    footprint.get(footprint.size() - 1).getLat(), footprint.get(footprint.size() - 1).getLon()
            );
            newR.setFixedPosition(footprint.get(footprint.size() - 1).getCoord());
            newFootprint.add(newR);
        }
        // ensure the first reading is included
        if (!newFootprint.get(0).equals(footprint.get(0))) {
            Reading newR = new Reading(
                    footprint.get(0).getEnteredTime(), footprint.get(0).getDeparturedTime(),
                    footprint.get(0).getLat(), footprint.get(0).getLon()
            );
            newR.setFixedPosition(footprint.get(0).getCoord());
            newFootprint.add(0, newR);
        }

        return newFootprint;
    }

    private static int findCentroid(List<Reading> footprint, Pair<Integer, Integer> window) {
        List<Integer> idSet = new ArrayList<>();
        for (int i = window._1(); i <= window._2(); i++) {
            idSet.add(i);
        }
        return findCentroid(footprint, idSet);
    }

    private static int findCentroid(List<Reading> footprint, List<Integer> idSet) {
//        double minDistance = Double.POSITIVE_INFINITY;
        double maxDistance = Double.NEGATIVE_INFINITY;
        int centroidIdx = -1;
        for (int i : idSet) {
            double distanceFromOthers = 0;
            for (int j : idSet) {
                distanceFromOthers += DistanceFunction.pointToPointDistance(footprint.get(i).getCoord(), footprint.get(j).getCoord());
            }

//            if (distanceFromOthers < minDistance) {
//                minDistance = distanceFromOthers;
//                centroidIdx = i;
//            }

            if (distanceFromOthers > maxDistance) {
                maxDistance = distanceFromOthers;
                centroidIdx = i;
            }
        }
        return centroidIdx;
    }


    public List<Reading> clusterUsingCenter(List<Reading> footprint, List<List<Integer>> windows) {
        List<Reading> newFootprint = new ArrayList<>();
        Set<Integer> filteredReadings = new HashSet<>();

        Map<List<Integer>, Coordinate<Double, Double>> windowMap = new HashMap<>();
        for (List<Integer> window : windows) {
            double lat = 0;
            double lon = 0;
            for (int i : window) {
                lat += footprint.get(i).getLat();
                lon += footprint.get(i).getLon();

                filteredReadings.add(i);
            }

            lat = lat / window.size();
            lon = lon / window.size();

            windowMap.put(window, new Coordinate<>(lat, lon));
        }

        Iterator<List<Integer>> it = windows.iterator();
        List<Integer> window = it.next();
        for (int i = 0; i < footprint.size(); i++) {
            if (window != null && window.contains(i)) {
                Reading newR = new Reading(footprint.get(i).getEnteredTime(), footprint.get(i).getDeparturedTime(),
                        footprint.get(i).getLat(), footprint.get(i).getLon());
                newR.setFixedPosition(windowMap.get(window));
                newFootprint.add(newR);
                window = it.next();
            } else if (!filteredReadings.contains(i)) {
                Reading newR = new Reading(footprint.get(i).getEnteredTime(), footprint.get(i).getDeparturedTime(),
                        footprint.get(i).getLat(), footprint.get(i).getLon());
                newR.setFixPosition(footprint.get(i).getLat(), footprint.get(i).getLon());
                newFootprint.add(newR);
            }
        }
        // ensure the last reading is included
        if (!newFootprint.get(newFootprint.size() - 1).equals(footprint.get(footprint.size() - 1))) {
            Reading newR = new Reading(
                    footprint.get(footprint.size() - 1).getEnteredTime(), footprint.get(footprint.size() - 1).getDeparturedTime(),
                    footprint.get(footprint.size() - 1).getLat(), footprint.get(footprint.size() - 1).getLon()
            );
            newR.setFixedPosition(footprint.get(footprint.size() - 1).getCoord());
            newFootprint.add(newR);
        }
        // ensure the first reading is included
        if (!newFootprint.get(0).equals(footprint.get(0))) {
            Reading newR = new Reading(
                    footprint.get(0).getEnteredTime(), footprint.get(0).getDeparturedTime(),
                    footprint.get(0).getLat(), footprint.get(0).getLon()
            );
            newR.setFixedPosition(footprint.get(0).getCoord());
            newFootprint.add(0, newR);
        }
        return newFootprint.size() > 1 ? newFootprint : new ArrayList<>(footprint);
    }

    public List<Reading> removeWeirdPoint(List<Reading> footprint, double degree) {
        Set<Integer> weirdPoints = new HashSet<>();
        for (int i = 1; i < footprint.size() - 1; i++) {
            Reading prevR = footprint.get(i - 1);
            Reading curR = footprint.get(i);
            Reading nextR = footprint.get(i + 1);

//            double direction = DistanceFunction.directionChange(prevR.getCoord(), curR.getCoord(), curR.getCoord(), nextR.getCoord());
//            if (direction > degree) {

            Coordinate<Double, Double> closestPoint = DistanceFunction.closestPointOnSegment(prevR.getCoord(), nextR.getCoord(), curR.getCoord());
            if (closestPoint.equals(prevR.getCoord()) || closestPoint.equals(nextR.getCoord())) {
                weirdPoints.add(i);
//
//                List<Integer> potentialBadPoints = new ArrayList<>();
//                for (int j = i-1; j <= i+1; j++) {
//                    double distance = DistanceFunction.pointToPointDistance(curR.getCoord(), footprint.get(j).getCoord());
//                    if ( distance < 2 * radius || isTemporalOverlapping(footprint, i, j)._1()) {
//                        potentialBadPoints.add(j);
//                    }
//                }
//
//                int centroid = findCentroid(footprint, potentialBadPoints);
//                for (int potentialBadPoint : potentialBadPoints) {
//                    if (potentialBadPoint != centroid) {
//                        weirdPoints.add(potentialBadPoint);
//                    }
//                }
            }
        }
        List<Reading> newFootprint = new ArrayList<>();
        for (int i = 0; i < footprint.size(); i++) {
            if (!weirdPoints.contains(i)) {
                Reading reading = footprint.get(i);
                Reading newR = new Reading(reading.getEnteredTime(), reading.getDeparturedTime(), reading.getLat(), reading.getLon());
                newR.setFixPosition(reading.getLat(), reading.getLon());
                newFootprint.add(newR);
            }
        }

        // ensure the last reading is included
        if (!newFootprint.get(newFootprint.size() - 1).equals(footprint.get(footprint.size() - 1))) {
            Reading newR = new Reading(
                    footprint.get(footprint.size() - 1).getEnteredTime(), footprint.get(footprint.size() - 1).getDeparturedTime(),
                    footprint.get(footprint.size() - 1).getLat(), footprint.get(footprint.size() - 1).getLon()
            );
            newR.setFixedPosition(footprint.get(footprint.size() - 1).getCoord());
            newFootprint.add(newR);
        }
        // ensure the first reading is included
        if (!newFootprint.get(0).equals(footprint.get(0))) {
            Reading newR = new Reading(
                    footprint.get(0).getEnteredTime(), footprint.get(0).getDeparturedTime(),
                    footprint.get(0).getLat(), footprint.get(0).getLon()
            );
            newR.setFixedPosition(footprint.get(0).getCoord());
            newFootprint.add(0, newR);
        }

        return newFootprint;
    }

}
