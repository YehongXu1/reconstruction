package transformations;

import observations.Reading;
import utilities.DistanceFunction;

import java.util.ArrayList;
import java.util.List;

/**
 * The Ramer–Douglas–Peucker algorithm (RDP) is an algorithm for reducing the number of points in a
 * curve that is approximated by a series of points.
 * <p>
 * @see <a href="https://en.wikipedia.org/wiki/Ramer%E2%80%93Douglas%E2%80%93Peucker_algorithm">Ramer–Douglas–Peucker Algorithm (Wikipedia)</a>
 * <br>
 * @author Justin Wetherell <phishman3579@gmail.com>
 */
public class RamerDouglasPeucker {

    private RamerDouglasPeucker() { }

    private static double sqr(double x) {
        return Math.pow(x, 2);
    }

    private static double distanceBetweenPoints(double vx, double vy, double wx, double wy) {
        return DistanceFunction.pointToPointDistance(vx, vy, wx, wy);
    }

    private static double distanceToSegmentSquared(double px, double py, double vx, double vy, double wx, double wy) {
//        final double l2 = distanceBetweenPoints(vx, vy, wx, wy);
//        if (l2 == 0)
//            return distanceBetweenPoints(px, py, vx, vy);
//        final double t = ((px - vx) * (wx - vx) + (py - vy) * (wy - vy)) / l2;
//        if (t < 0)
//            return distanceBetweenPoints(px, py, vx, vy);
//        if (t > 1)
//            return distanceBetweenPoints(px, py, wx, wy);
//        return distanceBetweenPoints(px, py, (vx + t * (wx - vx)), (vy + t * (wy - vy)));
        return DistanceFunction.pointClosestDistanceFromSegment(vx, vy, wx, wy, px, py);
    }

    private static double perpendicularDistance(double px, double py, double vx, double vy, double wx, double wy) {
        return Math.sqrt(distanceToSegmentSquared(px, py, vx, vy, wx, wy));
    }

    private static void douglasPeucker(List<Reading> footprint, int s, int e, double epsilon, List<Reading> resultList) {
        // Find the point with the maximum distance
        double dmax = 0;
        int index = 0;

        final int start = s;
        final int end = e-1;
        for (int i=start+1; i<end; i++) {
            // Point
            final double px = footprint.get(i).getLat();
            final double py = footprint.get(i).getLon();
            // Start
            final double vx = footprint.get(start).getLat();
            final double vy = footprint.get(start).getLon();
            // End
            final double wx = footprint.get(end).getLat();
            final double wy = footprint.get(end).getLon();
            final double d = perpendicularDistance(px, py, vx, vy, wx, wy);
            if (d > dmax) {
                index = i;
                dmax = d;
            }
        }
        // If max distance is greater than epsilon, recursively simplify
        if (dmax > epsilon) {
            // Recursive call
            douglasPeucker(footprint, s, index, epsilon, resultList);
            douglasPeucker(footprint, index, e, epsilon, resultList);
        } else {
            if ((end-start)>0) {
                resultList.add(footprint.get(start));
                resultList.add(footprint.get(end));
            } else {
                resultList.add(footprint.get(start));
            }
        }
    }

    /**
     * Given a curve composed of line segments find a similar curve with fewer points.
     *
     * @param footprint List of Double[] points (x,y)
     * @param epsilon Distance dimension
     * @return Similar curve with fewer points
     */
    public static List<Reading> douglasPeucker(List<Reading> footprint, double epsilon) {
        final List<Reading> resultList = new ArrayList<>();
        douglasPeucker(footprint, 0, footprint.size(), epsilon, resultList);
        return resultList;
    }
}