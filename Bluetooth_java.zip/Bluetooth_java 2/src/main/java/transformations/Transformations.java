package transformations;

import index.SpatialIndex;
import observations.Reading;
import utilities.Pair;

import java.util.List;

import static transformations.TemporalOrderings.*;

public class Transformations {
    private final SpatialIdentification spatialIdentification;

    public Transformations(SpatialIndex spatialIndex, double inquiryCycle, double radius) {
        this.spatialIdentification = new SpatialIdentification(spatialIndex, radius, inquiryCycle);
    }

    public List<Reading> orderByEnterTimeLocAtStation(List<Reading> footprint) {
        return this.spatialIdentification.fixAtStation(orderedByEnteredTime(footprint));
    }

    public List<Reading> orderByEnterTimeLocAtStationPlusDouglas(List<Reading> footprint, double epsilon) {
        return RamerDouglasPeucker.douglasPeucker(this.spatialIdentification.fixAtStation(orderedByEnteredTime(footprint)), epsilon);
    }

    public List<Reading> orderByEnterTimeLocGaussianDistribution(List<Reading> footprint, double gaussianScale) {
        return this.spatialIdentification.locationGaussianDistribution(orderedByEnteredTime(footprint), gaussianScale);
    }

    public List<Reading> orderByEnterTimeLocGaussianDistributionPlusDouglas(List<Reading> footprint, double epsilon, double gaussianScale) {
        return RamerDouglasPeucker.douglasPeucker(
                this.spatialIdentification.locationGaussianDistribution(orderedByEnteredTime(footprint), gaussianScale), epsilon);
    }

    public List<Reading> orderByEnterTimeLocWithinFiftyM(List<Reading> footprint) {
        return this.spatialIdentification.locationWithinDistance(orderedByEnteredTime(footprint), 0, 0.05);
    }

    public List<Reading> orderByEnterTimeLocWithinHundredM(List<Reading> footprint) {
        return this.spatialIdentification.locationWithinDistance(orderedByEnteredTime(footprint), 0.05, 0.1);
    }

    public List<Reading> orderByEnterTimeLocWithinTwoHundM(List<Reading> footprint) {
        return this.spatialIdentification.locationWithinDistance(orderedByEnteredTime(footprint), 0.1, 0.2);
    }

    public List<Reading> orderByEnterTimeLocAtClusterCentroidInSpace(List<Reading> footprint, int minSize) {
        List<List<Integer>> windows = this.spatialIdentification.clusterBySpace(footprint, minSize);
        return this.spatialIdentification.clusterUsingCentroid(orderedByEnteredTime(footprint), windows);
    }

    public List<Reading> orderByEnterTimeLocAtClusterCentroidInSpacePlusDouglas(List<Reading> footprint, int minSize, double epsilon) {
        List<List<Integer>> windows = this.spatialIdentification.clusterBySpace(footprint, minSize);
        return RamerDouglasPeucker.douglasPeucker(this.spatialIdentification.clusterUsingCentroid(orderedByEnteredTime(footprint), windows), epsilon);
    }

    public List<Reading> orderByEnterTimeLocAtClusterCentroidInSpacePlusDouglasPlusGaussianDist(List<Reading> footprint, int minSize, double epsilon, double gaussianScale) {
        List<List<Integer>> windows = this.spatialIdentification.clusterBySpace(footprint, minSize);
        return this.spatialIdentification.locationGaussianDistribution(
                RamerDouglasPeucker.douglasPeucker(
                        this.spatialIdentification.clusterUsingCentroid(
                                orderedByEnteredTime(footprint), windows), epsilon), gaussianScale);
    }

    public List<Reading> orderByEnterTimeLocAtClusterCentroidInTime(List<Reading> footprint, int minSize) {
        List<List<Integer>> windows = this.spatialIdentification.clusterByTime(footprint, minSize);
        return this.spatialIdentification.clusterUsingCentroid(orderedByEnteredTime(footprint), windows);
    }

    public List<Reading> orderByEnterTimeLocAtClusterCentroidInTimePlusDouglas(List<Reading> footprint, int minSize, double epsilon) {
        List<List<Integer>> windows = this.spatialIdentification.clusterByTime(footprint, minSize);
        return RamerDouglasPeucker.douglasPeucker(this.spatialIdentification.clusterUsingCentroid(orderedByEnteredTime(footprint), windows), epsilon);
    }

    public List<Reading> orderByEnterTimeLocAtClusterCentroidInTimePlusDouglasPlusGaussianDist(List<Reading> footprint, int minSize, double epsilon, double gaussianScale) {
        List<List<Integer>> windows = this.spatialIdentification.clusterByTime(footprint, minSize);
        return this.spatialIdentification.locationGaussianDistribution(
                RamerDouglasPeucker.douglasPeucker(this.spatialIdentification.clusterUsingCentroid(
                        orderedByEnteredTime(footprint), windows), epsilon), gaussianScale);
    }

    public List<Reading> orderByEnterTimeLocAtClusterCentroidInSpaceNTime(List<Reading> footprint, int minSize) {
        List<List<Integer>> windows = this.spatialIdentification.clusterBySpaceNTime(footprint, minSize);
        return this.spatialIdentification.clusterUsingCentroid(orderedByEnteredTime(footprint), windows);
    }

    public List<Reading> orderByEnterTimeLocAtClusterCentroidInSpaceNTimePlusDouglas(List<Reading> footprint, int minSize, double epsilon) {
        List<List<Integer>> windows = this.spatialIdentification.clusterBySpaceNTime(footprint, minSize);
        return RamerDouglasPeucker.douglasPeucker(this.spatialIdentification.clusterUsingCentroid(orderedByEnteredTime(footprint), windows), epsilon);
    }

    public List<Reading> orderByEnterTimeLocAtClusterCentroidInSpaceNTimePlusDouglasPlusGaussianDist(List<Reading> footprint, int minSize, double epsilon, double gaussianScale) {
        List<List<Integer>> windows = this.spatialIdentification.clusterBySpaceNTime(footprint, minSize);
        return this.spatialIdentification.locationGaussianDistribution(
                RamerDouglasPeucker.douglasPeucker(this.spatialIdentification.clusterUsingCentroid(
                        orderedByEnteredTime(footprint), windows), epsilon), gaussianScale);
    }

    public List<Reading> orderByEnterTimeLocAtClusterCenterInTime(List<Reading> footprint, int minSize) {
        List<List<Integer>> windows = this.spatialIdentification.clusterByTime(footprint, minSize);
//        for (Pair<Integer, Integer> window : windows) {
//            StringBuilder sb = new StringBuilder();
//            for (int i = window._1(); i <= window._2(); i++) {
//                sb.append(i);
//                sb.append(" ");
//            }
//            System.out.println(sb.toString());
//        }
        return this.spatialIdentification.clusterUsingCenter(orderedByEnteredTime(footprint), windows);
    }

    public List<Reading> orderByEnterTimeRemoveWeirdPoints(List<Reading> footprint, double thresholdDegree) {
        return this.spatialIdentification.removeWeirdPoint(orderedByEnteredTime(footprint), thresholdDegree);
    }

    public List<Reading> orderByEnterTimeRemoveWeirdPointsPlusDouglas(List<Reading> footprint, double thresholdDegree, double epsilon) {
        List<Reading> cleanedFt = this.spatialIdentification.removeWeirdPoint(orderedByEnteredTime(footprint), thresholdDegree);
        return RamerDouglasPeucker.douglasPeucker(cleanedFt, epsilon);

    }

    public List<Reading> orderByEnterTimeRemoveWeirdPointsPlusDouglasPlusGaussianDist(List<Reading> footprint, double thresholdDegree, double epsilon, double gaussianScale) {
        List<Reading> cleanedFt = this.spatialIdentification.removeWeirdPoint(orderedByEnteredTime(footprint), thresholdDegree);
        return this.spatialIdentification.locationGaussianDistribution(RamerDouglasPeucker.douglasPeucker(cleanedFt, epsilon), gaussianScale);

    }

    public List<Reading> orderByMidTimeLocAtStation(List<Reading> footprint) {
        return this.spatialIdentification.fixAtStation(orderedByMidTime(footprint));
    }


    public List<Reading> orderByMidTimeLocWithinFiftyM(List<Reading> footprint) {
        return this.spatialIdentification.locationWithinDistance(orderedByMidTime(footprint), 0, 0.05);
    }

    public List<Reading> orderByMidTimeLocWithinHundredM(List<Reading> footprint) {
        return this.spatialIdentification.locationWithinDistance(orderedByMidTime(footprint), 0.05, 0.1);
    }

    public List<Reading> orderByMidTimeLocWithinTwoHundM(List<Reading> footprint) {
        return this.spatialIdentification.locationWithinDistance(orderedByMidTime(footprint), 0.1, 0.2);
    }

    public List<Reading> orderByMidTimeLocAtClusterCentroidInSpace(List<Reading> footprint, int minSize) {
        List<List<Integer>> windows = this.spatialIdentification.clusterBySpace(footprint, minSize);
        return this.spatialIdentification.clusterUsingCentroid(orderedByMidTime(footprint), windows);
    }

    public List<Reading> orderByMidTimeLocAtClusterCentroidInTime(List<Reading> footprint, int minSize) {
        List<List<Integer>> windows = this.spatialIdentification.clusterByTime(footprint, minSize);
        return this.spatialIdentification.clusterUsingCentroid(orderedByMidTime(footprint), windows);
    }

    public List<Reading> orderByMidTimeLocAtClusterCenter(List<Reading> footprint, int minSize) {
        List<List<Integer>> windows = this.spatialIdentification.clusterBySpace(footprint, minSize);
        return this.spatialIdentification.clusterUsingCenter(orderedByMidTime(footprint), windows);
    }

    public List<Reading> orderByDepTimeLocAtStation(List<Reading> footprint) {
        return this.spatialIdentification.fixAtStation(orderedByDepartTime(footprint));
    }

    public List<Reading> orderByDepTimeLocWithinFiftyM(List<Reading> footprint) {
        return this.spatialIdentification.locationWithinDistance(orderedByDepartTime(footprint), 0, 0.05);
    }

    public List<Reading> orderByDepTimeLocWithinHundredM(List<Reading> footprint) {
        return this.spatialIdentification.locationWithinDistance(orderedByDepartTime(footprint), 0.05, 0.1);
    }

    public List<Reading> orderByDepTimeLocWithinTwoHundM(List<Reading> footprint) {
        return this.spatialIdentification.locationWithinDistance(orderedByDepartTime(footprint), 0.1, 0.2);
    }

    public List<Reading> orderByDepTimeLocAtClusterCentroidInSpace(List<Reading> footprint, int minSize) {
        List<List<Integer>> windows = this.spatialIdentification.clusterBySpace(footprint, minSize);
        return this.spatialIdentification.clusterUsingCentroid(orderedByDepartTime(footprint), windows);
    }

    public List<Reading> orderByDepTimeLocAtClusterCentroidInTime(List<Reading> footprint, int minSize) {
        List<List<Integer>> windows = this.spatialIdentification.clusterByTime(footprint, minSize);
        return this.spatialIdentification.clusterUsingCentroid(orderedByDepartTime(footprint), windows);
    }


    public List<Reading> orderByDepTimeLocAtClusterCenter(List<Reading> footprint, int minSize) {
        List<List<Integer>> windows = this.spatialIdentification.clusterBySpace(footprint, minSize);
        return this.spatialIdentification.clusterUsingCenter(orderedByDepartTime(footprint), windows);
    }

}
