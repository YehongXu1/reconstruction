package spatialObjects;

import utilities.DistanceFunction;

public class PointMatch {
    private Coordinate<Double, Double> matchedPoint;
    private Segment matchedSegment;
    String roadId;

    public PointMatch() {
        this.matchedPoint = new Coordinate<>(0, 0);
        this.matchedSegment = new Segment(0,0,0,0);
    }

    public PointMatch(Coordinate<Double, Double> matchingPoint, Segment matchedSegment, String roadID) {
        this.matchedPoint = matchingPoint;
        this.matchedSegment = matchedSegment;
        this.roadId = roadID;
    }

    public double lat(){
        return matchedPoint.getLat();
    }

    public double lon(){
        return matchedPoint.getLon();
    }

    public String getRoadID(){
        return roadId;
    }

    public Segment getMatchedSegment(){
        return matchedSegment;
    }

    public Coordinate<Double, Double> getMatchedPoint(){
        return matchedPoint;
    }

}
