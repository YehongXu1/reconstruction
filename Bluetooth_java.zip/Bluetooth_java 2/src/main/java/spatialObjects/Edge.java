package spatialObjects;

import utilities.DistanceFunction;

import java.util.Objects;

public class Edge {

    private Vertex source;
    private Vertex target;
    private String id;

    public Edge(Vertex source, Vertex target, String id) {
        this.source = source;
        this.target = target;
        this.id = id;
    }

    public Vertex getSource() {
        return this.source;
    }

    public Vertex getTarget() {
        return this.target;
    }

    public String getId(){return id;}

    public double getLengh(){
        return DistanceFunction.pointToPointDistance(source.getCoordinate(), target.getCoordinate());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Edge edge = (Edge) o;
        return Objects.equals(source, edge.source) &&
                Objects.equals(target, edge.target);
    }

    @Override
    public int hashCode() {
        return Objects.hash(source, target);
    }

    @Override
    public String toString() {
        return source.getCoordinate().toString() + "," + target.getCoordinate().toString()+";";
    }
}
