package spatialObjects;

import com.vividsolutions.jts.geom.LineSegment;
import utilities.DistanceFunction;

public class Segment {
    /**
     * Start-point coordinates
     */
    private final double lat1, lon1;
    /**
     * End-point coordinates
     */
    private final double lat2, lon2;
    /**
     * Auxiliary LineSegment from JTS old version
     */
    private LineSegment JTSLineSegment = null;

    /**
     * Creates a new empty line segment.
     */
    public Segment() {
        this.lat1 = 0.0;
        this.lon1 = 0.0;
        this.lat2 = 0.0;
        this.lon2 = 0.0;
    }

    /**
     * Creates a new line segment with the given start and end coordinates.
     *
     * @param lat1 Start-point X coordinate.
     * @param lon1 Start-point Y coordinate.
     * @param lat2 End-point X coordinate.
     * @param lon2 End-point Y coordinate.
     */
    public Segment(double lat1, double lon1, double lat2, double lon2) {
//        if (x1 == x2 && y1 == y2)
//            LOG.debug("Segment has the same endpoints: " + x1 + "," + y1 + "_" + x2 + "," + y2);
        this.lat1 = lat1;
        this.lon1 = lon1;
        this.lat2 = lat2;
        this.lon2 = lon2;
    }

    public Coordinate<Double, Double> getStartNode() {
        return new Coordinate<>(lat1, lon1);
    }

    public Coordinate<Double, Double> getEndNode() {
        return new Coordinate<>(lat2, lon2);
    }

    public double getLat1() {
        return lat1;
    }

    public double getLat2() {
        return lat2;
    }

    public double getLon1() {
        return lon1;
    }

    public double getLon2() {
        return lon2;
    }

    @Override
    public String toString() {
        return "[" + lat1 + "," + lon1 + "],[" + lat2 + "," + lon2 + "]";
    }
}
