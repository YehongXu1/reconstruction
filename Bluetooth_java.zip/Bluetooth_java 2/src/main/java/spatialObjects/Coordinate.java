package spatialObjects;

import utilities.DistanceFunction;

import java.util.Objects;

public class Coordinate<D extends Number, D1 extends Number> {

    private double lon;
    private double lat;

    public Coordinate(double lat, double lon) {
        this.lat = lat;
        this.lon = lon;
    }

    public double getLon() {
        return this.lon;
    }

    public double getLat() {
        return this.lat;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Coordinate<?, ?> that = (Coordinate<?, ?>) o;
        return Double.compare(that.lon, lon) == 0 &&
                Double.compare(that.lat, lat) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(lon, lat);
    }

    @Override
    public String toString() {
        return lat+" "+lon;
    }
}
