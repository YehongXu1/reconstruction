package spatialObjects;

import java.util.*;

public class Vertex {

    private String id;
    private Coordinate<Double, Double> coordinate;
    private Set<String> neighbours = new HashSet<>();

    public Vertex(String id, Coordinate<Double, Double> coordinate){
        this.id = id;
        this.coordinate=coordinate;
    }

    public String getId(){
        return id;
    }

    public Coordinate<Double,Double> getCoordinate(){
        return coordinate;
    }

    public void addNeighbours(String neighbour){
        neighbours.add(neighbour);
    }

    public Set<String> getNeighbours(){
        return neighbours;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Vertex vertex = (Vertex) o;
        return Objects.equals(id, vertex.id) &&
                Objects.equals(coordinate, vertex.coordinate) &&
                Objects.equals(neighbours, vertex.neighbours);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, coordinate, neighbours);
    }
}
