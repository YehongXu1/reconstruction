import evaluation.Evaluation;
import hmm.SimpleHMMMatching;
import index.RoadNetwork;
import index.SpatialIndex;
import observations.Reading;
import observations.Trace;
import spatialObjects.Edge;
import spatialObjects.PointMatch;
import transformations.Transformations;
import utilities.Pair;
import utilities.Triplet;

import java.io.*;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main {
    private static double radius = 0.2;

    public static List<Pair<List<Reading>, String[]>> smallScaleTestData(String smallScaleDataPath) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(smallScaleDataPath));
        String line = br.readLine();

        List<Pair<List<Reading>, String[]>> data = new ArrayList<>();
        while (line != null) {
            List<Reading> footprint = new ArrayList<>();
            String[] footprintArray = Arrays.asList(line.split(";")).get(0).split(",");
            for (String s : footprintArray) {
                String[] info = s.split("\\s");
                Reading reading = new Reading(Long.parseLong(info[2]), Long.parseLong(info[3]), Double.parseDouble(info[0]), Double.parseDouble(info[1]));
                footprint.add(reading);
            }
            String[] groundTruth = Arrays.asList(line.split(";")).get(1).split("\\s");

            data.add(new Pair<>(footprint, groundTruth));
            line = br.readLine();
        }

        return data;
    }

    public static void main(String[] args) throws IOException {
//        String edgePath = "/Users/xyh/Desktop/experimental results/edges_Brisbane.txt";
        String edgePath = "/Users/xyh/Documents/Bluetooth/data/input/map/edges_Brisbane.txt";
        String smallScaleDataPath = "/Users/xyh/Desktop/experimental results/ground_truths_edges.txt";
        String experimentalResults = "/Users/xyh/Desktop/experimental results/results.txt";
        BufferedWriter bw = new BufferedWriter(new FileWriter(experimentalResults));

        Main.smallScaleTestData(smallScaleDataPath);
        RoadNetwork roadNetwork = new RoadNetwork(edgePath);
        SpatialIndex spatialIndex = new SpatialIndex(roadNetwork);
        Transformations transformations = new Transformations(spatialIndex, 20, radius);

        List<Pair<List<Reading>, String[]>> footprintAndGroundTruths = smallScaleTestData(smallScaleDataPath);

        double[][] scores = new double[24][4];
        for (int i = 0; i < footprintAndGroundTruths.size(); i++) {
            System.out.println("Footprint " + (i + 1));
//            if (i < 14 ) {
//                continue;
//            }
            Pair<List<Reading>, String[]> footprintAndGroundTruth = footprintAndGroundTruths.get(i);

            List<Reading> footprint = footprintAndGroundTruth._1();
            String[] gt = footprintAndGroundTruth._2();

            List<Trace> traces = new ArrayList<>();
//            Trace trace1 = new Trace(Integer.toString(i), transformations.orderByEnterTimeLocAtStation(footprint));
//            traces.add(trace1);
//            Trace trace2 = new Trace(Integer.toString(i), transformations.orderByEnterTimeLocWithinFiftyM(footprint));
//            traces.add(trace2);
//            Trace trace3 = new Trace(Integer.toString(i), transformations.orderByEnterTimeLocWithinHundredM(footprint));
//            traces.add(trace3);
//            Trace trace4 = new Trace(Integer.toString(i), transformations.orderByEnterTimeLocWithinTwoHundM(footprint));
//            traces.add(trace4);
//            Trace trace5 = new Trace(Integer.toString(i), transformations.orderByEnterTimeLocAtClusterCentroidInSpace(footprint, 3));
//            traces.add(trace5);
//            Trace trace6 = new Trace(Integer.toString(i), transformations.orderByEnterTimeLocAtClusterCentroidInTime(footprint, 2));
//            traces.add(trace6);
//            Trace trace7 = new Trace(Integer.toString(i), transformations.orderByEnterTimeLocAtClusterCenterInTime(footprint, 2));
//            traces.add(trace7);
//            Trace trace25 = new Trace(Integer.toString(i), transformations.orderByEnterTimeRemoveWeirdPoints(footprint, 120));
//            traces.add(trace25);
//            Trace trace8 = new Trace(Integer.toString(i), transformations.orderByDepTimeLocAtStation(footprint));
//            traces.add(trace8);
//            Trace trace9 = new Trace(Integer.toString(i), transformations.orderByDepTimeLocWithinFiftyM(footprint));
//            traces.add(trace9);
//            Trace trace10 = new Trace(Integer.toString(i), transformations.orderByDepTimeLocWithinHundredM(footprint));
//            traces.add(trace10);
//            Trace trace11 = new Trace(Integer.toString(i), transformations.orderByDepTimeLocWithinTwoHundM(footprint));
//            traces.add(trace11);
//            Trace trace12 = new Trace(Integer.toString(i), transformations.orderByDepTimeLocAtClusterCentroidInSpace(footprint, 3));
//            traces.add(trace12);
//            Trace trace13 = new Trace(Integer.toString(i), transformations.orderByDepTimeLocAtClusterCentroidInTime(footprint, 2));
//            traces.add(trace13);
//            Trace trace14 = new Trace(Integer.toString(i), transformations.orderByDepTimeLocAtClusterCenter(footprint, 3));
//            traces.add(trace14);
//            Trace trace15 = new Trace(Integer.toString(i), transformations.orderByMidTimeLocAtStation(footprint));
//            traces.add(trace15);
//            Trace trace16 = new Trace(Integer.toString(i), transformations.orderByMidTimeLocWithinFiftyM(footprint));
//            traces.add(trace16);
//            Trace trace17 = new Trace(Integer.toString(i), transformations.orderByMidTimeLocWithinHundredM(footprint));
//            traces.add(trace17);
//            Trace trace18 = new Trace(Integer.toString(i), transformations.orderByMidTimeLocWithinTwoHundM(footprint));
//            traces.add(trace18);
//            Trace trace19 = new Trace(Integer.toString(i), transformations.orderByMidTimeLocAtClusterCentroidInSpace(footprint, 3));
//            traces.add(trace19);
//            Trace trace20 = new Trace(Integer.toString(i), transformations.orderByMidTimeLocAtClusterCentroidInTime(footprint, 2));
//            traces.add(trace20);
//            Trace trace21 = new Trace(Integer.toString(i), transformations.orderByMidTimeLocAtClusterCenter(footprint, 3));
//            traces.add(trace21);

//            Trace trace1 = new Trace(Integer.toString(i), transformations.orderByEnterTimeLocAtStation(footprint));
//            Trace trace2 = new Trace(Integer.toString(i), transformations.orderByEnterTimeLocAtClusterCentroidInSpace(footprint, 3));
//            Trace trace3 = new Trace(Integer.toString(i), transformations.orderByEnterTimeLocAtClusterCentroidInTime(footprint, 3));
//            Trace trace4 = new Trace(Integer.toString(i), transformations.orderByEnterTimeLocAtClusterCentroidInSpaceNTime(footprint, 3));
//            Trace trace5 = new Trace(Integer.toString(i), transformations.orderByEnterTimeRemoveWeirdPoints(footprint, 120));


//            Trace trace6 = new Trace(Integer.toString(i), transformations.orderByEnterTimeLocAtStationPlusDouglas(footprint, 2 * radius));
//            Trace trace7 = new Trace(Integer.toString(i), transformations.orderByEnterTimeLocAtClusterCentroidInSpacePlusDouglas(footprint, 3, 2 * radius));
//            Trace trace8 = new Trace(Integer.toString(i), transformations.orderByEnterTimeLocAtClusterCentroidInTimePlusDouglas(footprint, 3, 2 * radius));
//            Trace trace9 = new Trace(Integer.toString(i), transformations.orderByEnterTimeLocAtClusterCentroidInSpaceNTimePlusDouglas(footprint, 3, 2 * radius));
//            Trace trace10 = new Trace(Integer.toString(i), transformations.orderByEnterTimeRemoveWeirdPointsPlusDouglas(footprint, 100, 4 * radius));

            // Math.abs(r.nextGaussian()) * 0.01;
//            Trace trace9 = new Trace(Integer.toString(i), transformations.orderByEnterTimeLocGaussianDistributionPlusDouglas(footprint, 2 * radius, 0.05));
            Trace trace10 = new Trace(Integer.toString(i), transformations.orderByEnterTimeLocAtClusterCentroidInSpacePlusDouglasPlusGaussianDist(footprint, 3,2 * radius, 0.01));
            Trace trace11 = new Trace(Integer.toString(i), transformations.orderByEnterTimeLocAtClusterCentroidInTimePlusDouglasPlusGaussianDist(footprint, 3,2 * radius, 0.01));
//            Trace trace12 = new Trace(Integer.toString(i), transformations.orderByEnterTimeRemoveWeirdPointsPlusDouglas(footprint, 120,2 * radius));

//            traces.add(trace1);
//            traces.add(trace2);
//            traces.add(trace3);
//            traces.add(trace4);
//            traces.add(trace5);
//            traces.add(trace6);
//            traces.add(trace7);
//            traces.add(trace8);
//            traces.add(trace9);
            traces.add(trace10);
            traces.add(trace11);
//            traces.add(trace12);

            SimpleHMMMatching simpleHMMMatching = new SimpleHMMMatching(roadNetwork, 4, 0.008, "off", 0.05);
            for (int j = 0; j < traces.size(); j++) {
                Trace trace = traces.get(j);
                Triplet<String, List<PointMatch>, List<String>> results = simpleHMMMatching.offlineMatching(trace);
                System.out.println("    acc: " + Evaluation.accuracy(results._3(), Arrays.asList(gt)));
                System.out.println("    pre: " + Evaluation.precision(results._3(), Arrays.asList(gt)));
                System.out.println("    rec: " + Evaluation.recall(results._3(), Arrays.asList(gt)));
                System.out.println("    f1s: " + Evaluation.f1Score(results._3(), Arrays.asList(gt)));
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                scores[j][0] += Evaluation.accuracy(results._3(), Arrays.asList(gt));
                scores[j][1] += Evaluation.precision(results._3(), Arrays.asList(gt));
                scores[j][2] += Evaluation.recall(results._3(), Arrays.asList(gt));
                scores[j][3] += Evaluation.f1Score(results._3(), Arrays.asList(gt));

                StringBuilder sb = new StringBuilder();
                for (Reading t : trace.getTrace()) {
                    sb.append(t.getFixedPosition().toString());
                    sb.append(" ");
                    sb.append(t.getEnteredTime());
                    sb.append(" ");
                    sb.append(t.getDeparturedTime());
                    sb.append(",");
                }
                String path = sb.toString();
//                System.out.println(path);

                StringBuilder stringBuilder = new StringBuilder();
                for (String s : results._3()) {
                    Edge edge = roadNetwork.getEdges().get(s);
                    stringBuilder.append(s);
                    stringBuilder.append(" ");
                    stringBuilder.append(edge.toString());
                }
                String matchedPath = stringBuilder.toString();
//                System.out.println(matchedPath);

                bw.write(path + "&" + matchedPath + "\n");

            }
//            break;
        }

        for (int j = 0; j < 21; j++) {

            System.out.println("~~~~~~~~~~~~~The " + j + "-th Transformation~~~~~~~~~~~~");
            System.out.println("acc: " + String.format("%.4f", scores[j][0] / footprintAndGroundTruths.size()));
            System.out.println("pre: " + String.format("%.4f", scores[j][1] / footprintAndGroundTruths.size()));
            System.out.println("rec: " + String.format("%.4f", scores[j][2] / footprintAndGroundTruths.size()));
            System.out.println("f1s: " + String.format("%.4f", scores[j][3] / footprintAndGroundTruths.size()));

        }
        bw.flush();
        bw.close();
    }
}
