package observations;

import spatialObjects.Coordinate;

import java.util.Objects;

public class Reading {
    private long enteredTime;
    private long departuredTime;
//    private Station stationPoint;
    private Coordinate<Double, Double> coordinate;
    private Coordinate<Double, Double> fixedPosition = new Coordinate<>(0,0);

//    public Reading(long enteredTime, long departuredTime, Station stationPoint) {
//        this.enteredTime = enteredTime;
//        this.departuredTime = departuredTime;
//        this.stationPoint = stationPoint;
//        coordinate = new Coordinate<>(this.stationPoint.getLatitude(), this.stationPoint.getLongitude());
//    }

    public Reading(long startTime, long departuredTime, Coordinate<Double, Double> point) {
        this.enteredTime = startTime;
        this.departuredTime = departuredTime;
        this.coordinate = point;
    }

    public Reading(long startTime, long departuredTime, double lat, double lon) {
        this.enteredTime = startTime;
        this.departuredTime = departuredTime;
        this.coordinate = new Coordinate<>(lat, lon);
    }

    public long getEnteredTime() {
        return enteredTime;
    }

    public long getDeparturedTime() {
        return departuredTime;
    }

    public Coordinate<Double, Double> getCoord() {
        return coordinate;
    }

    public Coordinate<Double, Double> getFixedPosition() {
        return fixedPosition;
    }

    public long getDuration() {
        return departuredTime - enteredTime;
    }

    public double getLat() {
        return coordinate.getLat();
    }

    public double getLon() {
        return coordinate.getLon();
    }

    public double getPositionLat(){
        return fixedPosition.getLat();
    }

    public double getPositionLon(){
        return fixedPosition.getLon();
    }

    public void setFixPosition(double lat, double lon) {
        this.fixedPosition = new Coordinate<>(lat, lon);
    }

    public void setFixedPosition(Coordinate<Double, Double> loc){
        this.fixedPosition = new Coordinate<>(loc.getLat(), loc.getLon());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Reading that = (Reading) o;
        return enteredTime == that.enteredTime &&
                departuredTime == that.departuredTime &&
                Objects.equals(coordinate, that.coordinate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(enteredTime, departuredTime,coordinate);
    }
}
