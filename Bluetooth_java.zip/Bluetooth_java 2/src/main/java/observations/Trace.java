package observations;

import java.util.List;

public class Trace {
    private String id;

    private List<Reading> trace;

    public Trace(String id, List<Reading> trace){
        this.id = id;
        this.trace = trace;
    }

    public String getId(){
        return id;
    }

    public List<Reading> getTrace(){
        return trace;
    }

    public int size(){
        return trace.size();
    }

    public Reading get(int i){
        if (i < size()){
            return trace.get(i);
        }
        else return null;
    }
}
