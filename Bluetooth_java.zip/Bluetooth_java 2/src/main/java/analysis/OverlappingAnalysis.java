package analysis;

import index.RoadNetwork;
import index.Station;
import observations.Reading;
import utilities.DistanceFunction;
import utilities.Pair;
import utilities.Utilities;

import java.io.IOException;
import java.text.ParseException;
import java.util.*;

public class OverlappingAnalysis {
    private static final double inquiryCycle = 10.24;
    private static final double radius = 0.1;

    private static List<String> intersection(List<String> list1, List<String> list2) {
        List<String> list3 = new ArrayList<>(list1);
        list3.retainAll(list2);
        return list3;
    }

    private static Pair<Boolean, Double> isOverlapping(List<Reading> trace, int cur, int pre) {
        Pair<Double, Double> curTimeInterval =
                new Pair<>(trace.get(cur).getEnteredTime() - inquiryCycle, (double) trace.get(cur).getDeparturedTime());

        Pair<Double, Double> prevTimeInterval =
                new Pair<>(trace.get(pre).getEnteredTime() - inquiryCycle, (double) trace.get(pre).getDeparturedTime());

        double temporalGap = curTimeInterval._1() - prevTimeInterval._2();

        boolean overlap = temporalGap < 0;
        return new Pair<>(overlap, temporalGap);
    }

    private static Pair<Boolean, Double> isTemporalOverlapping(List<Reading> trace, int cur, int pre) {
        Pair<Double, Double> curTimeInterval =
                new Pair<>(trace.get(cur).getEnteredTime() - inquiryCycle, (double) trace.get(cur).getEnteredTime() + trace.get(cur).getDuration());

        Pair<Double, Double> prevTimeInterval =
                new Pair<>(trace.get(pre).getEnteredTime() - inquiryCycle, (double) trace.get(pre).getEnteredTime() + trace.get(pre).getDuration());

        double overlappingTime = curTimeInterval._1() - prevTimeInterval._2();
        return new Pair<>(overlappingTime < 0, overlappingTime);
    }

    private static Pair<Boolean, Double> isSpatialOverlapping(List<Reading> trace, int cur, int pre) {
        double dist = DistanceFunction.pointToPointDistance(trace.get(cur).getCoord(), trace.get(pre).getCoord());
        return new Pair<>(dist < 2 * radius, dist);
    }

    public static Pair<List<Reading>, List<Pair<Integer, Integer>>> detectOverlappingRegion(List<Reading> trace, int minSize) {
        List<Reading> newTrace = new ArrayList<>();

        List<Pair<Integer, Integer>> overlappingWindows = new ArrayList<>();
        Set<Integer> unindependentIdxs = new HashSet<>();
        List<Integer> includedIdx = new ArrayList<>();

        int windowStart = 0;
        int windowEnd = 0;

        for (int i = 1; i < trace.size(); i++) {

            if (i == 37) {
                System.out.println();
            }

            if (isOverlapping(trace, i, i - 1)._1()) {
                if (windowStart == 0) {
                    // a new overlapping region
                    windowStart = i - 1;
                    windowEnd = i;
                } else {
                    int inspectIdx = windowEnd;
                    while (inspectIdx >= windowStart) {
                        if (!isOverlapping(trace, i, inspectIdx)._1()) break;
                        inspectIdx -= 1;
                    }

                    if (inspectIdx == windowStart - 1) {
                        // trace[i] overlaps with every reading in cur window, extend cur window
                        windowEnd = i;
                    } else {
                        // trace[i] does not overlap with all readings in cur window
                        if (windowEnd - windowStart + 1 >= minSize) {
                            for (int j = windowStart; j <= windowEnd; j++) {
                                unindependentIdxs.add(j);
                            }
                            unindependentIdxs.remove((int) Math.ceil(((double) windowStart + (double) windowEnd) / 2.0)); // include the centroid
//                            includedIdx.add(windowStart);
                            overlappingWindows.add(new Pair<>(windowStart, windowEnd));
                        }
                        windowEnd = i;
                        windowStart = inspectIdx + 1;
                    }
                }
            } else {
                // break from previous reading
                if (windowStart > 0) {
                    if (windowEnd - windowStart + 1 >= minSize) {
                        for (int j = windowStart; j <= windowEnd; j++) {
                            unindependentIdxs.add(j);
                        }
                        unindependentIdxs.remove((int) Math.ceil(((double) windowStart + (double) windowEnd) / 2.0));
//                        includedIdx.add(windowStart);
                        overlappingWindows.add(new Pair<>(windowStart, windowEnd));
                    }
                    windowStart = 0;
                    windowEnd = 0;
                }
            }
        }

        if (windowEnd - windowStart + 1 >= minSize) {
            for (int j = windowStart; j <= windowEnd; j++) {
                unindependentIdxs.add(j);
            }
            unindependentIdxs.remove((int) Math.ceil(((double) windowStart + (double) windowEnd) / 2.0));
//                        includedIdx.add(windowStart);
            overlappingWindows.add(new Pair<>(windowStart, windowEnd));
        }

        for (int i = 0; i < trace.size(); i++) {
            if (!unindependentIdxs.contains(i)) {
                includedIdx.add(i);
            }
        }
        Collections.sort(includedIdx);
        for (Integer idx : includedIdx) {
            newTrace.add(trace.get(idx));
        }
        return new Pair<>(newTrace, overlappingWindows);
    }

    public static Pair<List<Reading>, List<Pair<Integer, Integer>>> detectOverlappingRegion2(List<Reading> trace, int minSize) {
        List<Reading> newTrace = new ArrayList<>();

        List<Pair<Integer, Integer>> overlappingWindows = new ArrayList<>();
        Set<Integer> unindependentIdxs = new HashSet<>();
        List<Integer> includedIdx = new ArrayList<>();

        int windowStart = 0;
        int windowEnd = 0;

        for (int i = 1; i < trace.size(); i++) {
            if (isOverlapping(trace, i, windowStart)._1()) {
                // trace[i] overlap with trace[winstart]
                windowEnd = i;
            } else {
                if (windowEnd - windowStart + 1 >= minSize) {
                    overlappingWindows.add(new Pair<>(windowStart, windowEnd));
                    for (int j = windowStart + 1; j <= windowEnd; j++) { // reserve trace[winstart]
                        unindependentIdxs.add(j);
                    }
                }

                windowStart = i;
                windowEnd = i;
            }
        }

        if (windowEnd - windowStart + 1 > minSize){
            overlappingWindows.add(new Pair<>(windowStart, windowEnd));
            for (int j = windowStart + 1; j <= windowEnd; j++) { // reserve trace[winstart]
                unindependentIdxs.add(j);
            }
        }

        for (int i = 0; i < trace.size(); i++) {
            if (!unindependentIdxs.contains(i)) {
                includedIdx.add(i);
            }
        }
        Collections.sort(includedIdx);
        for (Integer idx : includedIdx) {
            newTrace.add(trace.get(idx));
        }
        return new Pair<>(newTrace, overlappingWindows);
    }

    public static void main(String[] args) throws IOException, ParseException {
        String edge_Path = "/Users/xyh/Documents/Bluetooth/Bluetooth-visualization/Data/input/edges_Brisbane.txt";
        String stationPath = "/Users/xyh/Documents/Bluetooth/Bluetooth-visualization/Data/input/station.txt";
        String folder_path = "/Users/xyh/Documents/Bluetooth/Bluetooth-visualization/Data/input/raw";
//        String overlappingAnalysis = "/Users/xyh/Desktop/statistics/traces/overlatpping.txt";
        String overlappingRegionAnalysis = "/Users/xyh/Desktop/statistics/traces/overlappingRegionAnalysis.txt";
        String closenessAnalysis = "/Users/xyh/Desktop/statistics/traces/closeness.txt";
        String path_w = "/Users/xyh/Desktop/statistics/traces/overlapping_analysis.txt";

        RoadNetwork roadNetwork = new RoadNetwork(edge_Path);
        Map<String, Station> stations = Preprocessing.getStations(stationPath, roadNetwork);
        List<String> filePaths = Utilities.readFolder(folder_path);

//        BufferedWriter bw = new BufferedWriter(new FileWriter(overlappingRegionAnalysis));
//        bw.write("meanDist medianDist meanT medianT\n");
        int[] sizeCounts = new int[20];

        for (String filePath : filePaths) {
            System.out.println(filePath);
            Map<String, List<Reading>> oneDayRaw = Preprocessing.parseRawData(filePath, stations);
            for (Map.Entry<String, List<Reading>> macIdToTrace : oneDayRaw.entrySet()) {

                List<Reading> trace = macIdToTrace.getValue();
                if (trace.size() < 2) continue;

                Pair<List<Reading>, List<Pair<Integer, Integer>>> pair = detectOverlappingRegion(trace, 2);
                List<Pair<Integer, Integer>> windows = pair._2();

                int totalSize = 0;


                for (Pair<Integer, Integer> window : windows) {
                    int size = window._2() - window._1() + 1;
                    totalSize += size;

                    sizeCounts[size - 2] = sizeCounts[size - 2] + 1;
                }
//                if (totalSize == 0) {
//                    bw.write(0 + " " + 0 + "\n");
//                } else {
//                    bw.write((double) windows.size()/(double) trace.size()+" "+(double) totalSize/(double) windows.size()+"\n");
//                }
//                List<Double> dists = new ArrayList<>();
//                List<Double> temporalGaps = new ArrayList<>();
//                if (trace.size() == 1) continue;
//                for (int i = 1; i < trace.size(); i++) {
//                    double temporalGap = trace.get(i).getEnteredTime() - trace.get(i - 1).getEnteredTime();
//                    double dist = DistanceFunction.pointToPointDistance(trace.get(i).getLocation(), trace.get(i - 1).getLocation());
//                    dists.add(dist);
//                    temporalGaps.add(temporalGap);
//                }
//                double meanDist = Utilities.mean(dists);
//                double medianDist = Utilities.median(dists);
//
//                double meanT = Utilities.mean(temporalGaps);
//                double medianT = Utilities.median(temporalGaps);
//                bw.write(meanDist + " " + medianDist + " " + meanT + " " + medianT + "\n");
            }
        }
//        bw.flush();
//        bw.close();
        for (int i = 0; i < sizeCounts.length; i++) {
            System.out.println(i + 2 + ": " + sizeCounts[i]);
        }
    }
}
