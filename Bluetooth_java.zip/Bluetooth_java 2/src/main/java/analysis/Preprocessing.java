package analysis;

import index.RoadNetwork;
import index.Station;

import java.io.*;
import java.text.ParseException;
import java.util.*;

import observations.Reading;
import utilities.DistanceFunction;
import utilities.Utilities;

public class Preprocessing {

    private final static int temporalThreshold = 3600;
    private final static int minPointNum = 2;
    private final static int minSpeed = 5;
    private final static double radius = 0.1;

    public static Map<String, Station> getStations(String stationPath, RoadNetwork roadNetwork) throws IOException {
        return Station.iniStations(stationPath, roadNetwork, radius);
    }

    /**
     * Parse raw trajectory data
     *
     * @param filePath: path of the bluetooth data in a day
     * @return Map, key: macId; value: trajectory points of A MACID in this day
     * @throws IOException
     * @throws ParseException
     */
    public static Map<String, List<Reading>> parseRawData(String filePath, Map<String, Station> stationMap) throws IOException, ParseException {
        Map<String, List<Reading>> processedData = new HashMap<>();

        BufferedReader br = new BufferedReader(new FileReader(filePath));

        String line = br.readLine(); // 4481369,2016-06-01 00:00:00,1,B0015,-27.42999800,153.03253600,BCC
        line = br.readLine(); // omit the first line

        while (line != null) {
            List<String> info = Arrays.asList(line.split(","));
            String macID = info.get(0);
            long enteredTime = Utilities.transformToSecond(info.get(1));
            int duration = Integer.parseInt(info.get(2));
            long departureTime = enteredTime + duration;

            Station station = stationMap.get(info.get(3));
            Reading point = new Reading(enteredTime, departureTime, station.getLatitude(), station.getLongitude());


            processedData.computeIfAbsent(macID, k -> new ArrayList<>());

            List<Reading> points = processedData.get(macID);
//            if (points.size() > 0) {
//                TrajectoryPoint lastPoint = points.get(points.size() - 1);
//                if (lastPoint.getEnteredTime() == point.getEnteredTime()) {
//                    point.setEnteredTime(point.getEnteredTime() + 0.1d);
//                }
//            }

            points.add(point);
            processedData.put(macID, points);
            line = br.readLine();
        }
        br.close();
        return processedData;
    }

    public static int[] countOverlapping(Map<String, List<Reading>> rawData) {
        int totalCnt = 0;
        int overlapping = 0;

        for (Map.Entry<String, List<Reading>> macIDToPoints : rawData.entrySet()) {
            List<Reading> points = macIDToPoints.getValue();
            totalCnt += points.size();
            for (int i = 1; i < points.size(); i++) {
                long gap = points.get(i).getEnteredTime() - points.get(i - 1).getEnteredTime();
                double dist = DistanceFunction.pointToPointDistance(
                        points.get(i).getLat(), points.get(i).getLon(),
                        points.get(i - 1).getLat(), points.get(i - 1).getLon());

                if (gap == 0 || dist < 0.5 * radius) {
                    overlapping += 1;
                }
            }
        }

        return new int[]{totalCnt, overlapping};
    }


    /**
     * Find macids that are shared by more than one device in a day
     *
     * @param oneDayRawData Map<macId, trajectory points of A MACID in this day>
     * @return Map<macId, # times this id has conflict record>
     */
    public static Map<String, Integer> findErrorMacIdsInADay(Map<String, List<Reading>> oneDayRawData) {
        Map<String, Integer> filteredMacIdsToCnt = new HashMap<>();

        for (Map.Entry<String, List<Reading>> idToTrajectoriesPoints : oneDayRawData.entrySet()) {
            String macId = idToTrajectoriesPoints.getKey();
            List<Reading> trajectoryPoints = idToTrajectoriesPoints.getValue();

            for (int i = 1; i < trajectoryPoints.size(); i++) {
                long timeGap = trajectoryPoints.get(i - 1).getEnteredTime() - trajectoryPoints.get(i).getEnteredTime();
                double distance = DistanceFunction.pointToPointDistance(
                        trajectoryPoints.get(i - 1).getLat(), trajectoryPoints.get(i).getLon(),
                        trajectoryPoints.get(i).getLat(), trajectoryPoints.get(i).getLon()
                );
                if (distance > 2 * radius && timeGap > (distance - 2 * radius) / minSpeed * 3600) {

                    if (filteredMacIdsToCnt.get(macId) == null) {
                        filteredMacIdsToCnt.put(macId, 1);
                    } else {

                        int curCnt = filteredMacIdsToCnt.get(macId);
                        filteredMacIdsToCnt.put(macId, curCnt + 1);
                    }
                }
            }
        }
        return filteredMacIdsToCnt;
    }


    /**
     * Clean trajectory,
     * including identify individual trajectories for each device and reduce redundant points in a trajectory
     *
     * @param rawData
     * @return Map.Entry<# of trajectories that are filtered, Map < macId, individualTrajectories that are segmented and cleaned>>
     */
    public static Map<String, List<List<Reading>>> trajectoryCleaning(
            Map<String, List<Reading>> rawData, List<String> errorMacIds) {

        Map<String, List<List<Reading>>> macIdToSegmentedTrajectories = new LinkedHashMap<>();

        // process trajectory points for each user
        for (Map.Entry<String, List<Reading>> onesTrajecs : rawData.entrySet()) {

            String macID = onesTrajecs.getKey();

            if (errorMacIds.contains(macID)) continue;

            List<Reading> trajectories = onesTrajecs.getValue();
            List<List<Reading>> individualTrajectories = trajectoryIdentification(trajectories);

            // try to remove redundant points in each trajectory when trajectory is relatively long
            List<List<Reading>> augmentedTrajectories = new ArrayList<>();
            for (List<Reading> trajectoryPoints : individualTrajectories) {

                if (trajectoryPoints.size() >= 0) { // cancel max value
                    List<Reading> augmentedTrajectory = reduceRedundantPoints(trajectoryPoints);
                    if (augmentedTrajectory.size() >= minPointNum) {
                        augmentedTrajectories.add(augmentedTrajectory);
                    }
                } else {
                    augmentedTrajectories.add(trajectoryPoints);
                }
            }
            macIdToSegmentedTrajectories.put(macID, augmentedTrajectories);
        }
        return macIdToSegmentedTrajectories;
    }


    /**
     * For trajectory points of A certain macid,
     * count number of trajectories that are filtered . && Identifies individual trajectories for one device
     *
     * @param onesTrajectories
     * @return Map.Entry<# filtered trajectories, lists of individual trajectories of this ID>>
     * or return Map.Entry<0, null> if this macid has conflict records
     */
    public static List<List<Reading>> trajectoryIdentification(List<Reading> onesTrajectories) {

        List<List<Reading>> individualTrajectories = new ArrayList<>();

        List<Reading> trajectory = new ArrayList<>();
        trajectory.add(onesTrajectories.get(0));

        Set<String> stationIds = new HashSet<>(); // stations of previous trip
        stationIds.add(onesTrajectories.get(0).getCoord().toString());

        for (int i = 1; i < onesTrajectories.size(); i++) {
            Reading prevPoint = onesTrajectories.get(i - 1);
            Reading curPoint = onesTrajectories.get(i);

            if (curPoint.getCoord().equals(prevPoint.getCoord())) continue;

            long timeGap = curPoint.getEnteredTime() - prevPoint.getEnteredTime();

            // satisfy criteria of segmentation or visit a place previously visited
            if (timeGap >= temporalThreshold || stationIds.contains(curPoint.getCoord().toString())) {
                if (trajectory.size() >= minPointNum) {
                    individualTrajectories.add(new ArrayList<>(trajectory));
                }
                trajectory = new ArrayList<>();
                stationIds = new HashSet<>();
            }
            trajectory.add(curPoint);
            stationIds.add(curPoint.getCoord().toString());
        }

        if (trajectory.size() >= minPointNum) {
            individualTrajectories.add(trajectory);
        }
        return individualTrajectories;
    }


    /**
     * Deal with redundant point in a trajectory
     * Points considered redundant: 1. Temporal gap == 0; or 2. Distance between two observations less than 0.5 * radius
     *
     * @param trajectoryPoints
     * @return trajectory without redundant points
     */
    private static List<Reading> reduceRedundantPoints(List<Reading> trajectoryPoints) {
        List<Reading> reducedTrajectory = new ArrayList<>();
        int idx = 0;

        Reading prevPoint = null;
        for (Reading curPoint : trajectoryPoints) {
            idx += 1;
            if (prevPoint == null) {
                prevPoint = curPoint;
                reducedTrajectory.add(prevPoint);
                continue;
            }

            String stationPrev = prevPoint.getCoord().toString();
            String stationCurr = curPoint.getCoord().toString();

            // current point is redundant
            if (stationPrev.equals(stationCurr)) {
                continue;
            }

            reducedTrajectory.add(curPoint);
            prevPoint = curPoint;

//            long temporalGap = curPoint.getEnteredTime() - prevPoint.getEnteredTime();
//            double distance = utilities.Utilities.DistanceFunction.pointToPointDistance(
//                    curPoint.getLatitude(), curPoint.getLongitude(), prevPoint.getLatitude(), prevPoint.getLongitude());
//
//            /* Redundant detection */
//            if (temporalGap == 0 || distance < 0.5 * radius) {
//
//                // if curpoint is the last, preserve curpoint and discard prevpoint
//                if (idx == trajectoryPoints.size()) {
//                    reducedTrajectory.remove(prevPoint);
//                    reducedTrajectory.add(curPoint);
//                } else {
//                    observations.TrajectoryPoint nextPoint = trajectoryPoints.get(idx);
//
//                    String pathIDPrev = stationPrev.getPathId();
//                    String pathIDCurr = stationCurr.getPathId();
//                    String pathIdNext = nextPoint.getStationPoint().getPathId();
//
//                    if (pathIDPrev.equals(pathIDCurr) && pathIDCurr.equals(pathIdNext)) {
//                        // a = b = c try to preserve the one at intersection
//                        if (stationCurr.atIntersection()) {
//                            reducedTrajectory.remove(prevPoint);
//                            reducedTrajectory.add(curPoint);
//                            prevPoint = curPoint;
//                        }
//
//                    } else if (!pathIDPrev.equals(pathIDCurr) && !pathIDCurr.equals(pathIdNext) && !pathIDPrev.equals(pathIdNext)) {
//                        // a != b != c
//                        if (!stationPrev.atIntersection()) {
//                            reducedTrajectory.remove(prevPoint);
//                            reducedTrajectory.add(curPoint);
//                            prevPoint = curPoint;
//                        }
//                    } else if (pathIDPrev.equals(pathIDCurr) && !pathIDCurr.equals(pathIdNext)) {
//                        // a = b & b != c try to preserve the one at intersection
//                        if (stationCurr.atIntersection()) {
//                            reducedTrajectory.remove(prevPoint);
//                            reducedTrajectory.add(curPoint);
//                            prevPoint = curPoint;
//                        }
//                    } else if (pathIDPrev.equals(pathIdNext) && !pathIDCurr.equals(pathIDPrev)) {
//                        // a = c & b != c preserve prev point
//                        continue;
//                    } else if (pathIDCurr.equals(pathIdNext) && pathIDPrev.equals(pathIDCurr)) {
//                        // b = c & a != b
//                        reducedTrajectory.remove(prevPoint);
//                        reducedTrajectory.add(curPoint);
//                        prevPoint = curPoint;
//                    }
//                }
//
//            } else {
//                reducedTrajectory.add(curPoint);
//                prevPoint = curPoint;
//            }
        }
        return reducedTrajectory;
    }


    public static double[] summarize(Map.Entry<Integer, Map<String, List<List<Reading>>>> cntToCleanedDataAday) throws IOException {
        int cnt = cntToCleanedDataAday.getKey();
        Map<String, List<List<Reading>>> cleanedDataAday = cntToCleanedDataAday.getValue();
        String durationNLength = "/Users/xyh/Desktop/statistics/duration+size+distance_minspeed_considered.txt";
        BufferedWriter bw = new BufferedWriter(new FileWriter(durationNLength));
        bw.write("duration,observations,trajectoryLength\n");

        int no_trajectories = 0;
        double totalTrajectoryLengths = 0;
        double totalTravelDistances = 0;
        double totalTravelTime = 0;
        double totalSpeeds = 0;

        for (Map.Entry<String, List<List<Reading>>> onesTrajectories : cleanedDataAday.entrySet()) {
            List<List<Reading>> trajectories = onesTrajectories.getValue();

            no_trajectories += trajectories.size();
            for (List<Reading> trajectory : trajectories) {
                /* for each trajectory */
                double trajectoryDistance = 0;
                for (int i = 1; i < trajectory.size(); i++) {
                    Reading prev = trajectory.get(i - 1);
                    Reading curr = trajectory.get(i);

                    double moveLength = DistanceFunction.pointToPointDistance(
                            prev.getLat(), prev.getLon(), curr.getLat(), curr.getLon());

                    trajectoryDistance += moveLength;
                }
                totalTrajectoryLengths += trajectory.size();

                long trajectoryTravelTime = trajectory.get(trajectory.size() - 1).getEnteredTime()
                        - trajectory.get(0).getEnteredTime();
                totalTravelTime += trajectoryTravelTime;

                totalTravelDistances += trajectoryDistance;

                double speed = trajectoryTravelTime != 0 ? trajectoryDistance / trajectoryTravelTime * 3600 : minSpeed;

                if (Double.isNaN(speed) || Double.isNaN(totalSpeeds)) {
                    continue;
                }
                totalSpeeds += speed;

                bw.write(trajectoryTravelTime + "," + trajectory.size() + "," + trajectoryDistance + "\n");
            }

        }

        bw.flush();
        bw.close();
        System.out.println("num of filtered: " + cnt);
        System.out.println("num of trajectories: " + no_trajectories);
        System.out.println("mean trajectory point number: " + totalTrajectoryLengths / no_trajectories);
        System.out.println("mean trajectory distance: " + totalTravelDistances / no_trajectories);
        System.out.println("mean trajectory time: " + totalTravelTime / no_trajectories);
        System.out.println("mean speed: " + totalSpeeds / no_trajectories + "\n");

        return new double[]{cnt,
                no_trajectories,
                totalTrajectoryLengths / no_trajectories,
                totalTravelDistances / no_trajectories,
                totalTravelTime / no_trajectories,
                totalSpeeds / no_trajectories
        };
    }

    public static void writeStat(String pathToWrite, Map<String, double[]> report) throws IOException {
//

        BufferedWriter bw = new BufferedWriter(new FileWriter(pathToWrite));
        String head = "date, # trajectories filtered,num of trajectories,mean trajectory point number,mean trajectory distance,mean trajectory time,mean speed\n";
        bw.write(head);

        int totalFilterdCount = 0;
        int totalTrajCount = 0;
        for (Map.Entry<String, double[]> entry : report.entrySet()) {
            double[] info = entry.getValue();
            totalFilterdCount += info[0];
            totalTrajCount += info[1];

            String date = Arrays.asList(entry.getKey().split("/")).get(9);
            String s = date + "," + (int) info[0] + "," + (int) info[1] + "," + info[2] + "," + info[3] + "," + info[4] + "," + info[5] + "\n";
            bw.write(s);
        }
        bw.flush();
        bw.close();
        System.out.println("filtered: " + totalFilterdCount + "; # trajectories: " + totalTrajCount);

    }

    public static void collectErrorMacIds(String pathToWriteErrorIds, List<String> filePaths,
                                          Map<String, Station> stations) throws IOException, ParseException {
        Map<String, Integer> errorMacIdsToCnts = new HashMap<>();
        Set<String> macIds = new HashSet<>();

        for (String filePath : filePaths) {
            System.out.println(filePath);
            Map<String, List<Reading>> oneDayRaw = parseRawData(filePath, stations);
            Map<String, Integer> idToCnt = findErrorMacIdsInADay(oneDayRaw);


            for (String id : idToCnt.keySet()) {
                macIds.add(id);

                if (errorMacIdsToCnts.get(id) == null) {
                    errorMacIdsToCnts.put(id, idToCnt.get(id));
                } else {

                    int prevCnt = errorMacIdsToCnts.get(id);
                    errorMacIdsToCnts.put(id, prevCnt + idToCnt.get(id));
                }
            }
        }

        List<String> errorMacIds = new ArrayList<>();
        for (Map.Entry<String, Integer> idToCnt : errorMacIdsToCnts.entrySet()) {
            if (idToCnt.getValue() > 60) {
                errorMacIds.add(idToCnt.getKey());
            }
        }
        System.out.println("total # device: " + macIds.size() + "; # error macids: " + errorMacIds.size());

        BufferedWriter bw1 = new BufferedWriter(new FileWriter(pathToWriteErrorIds));
        for (String errorMacId : errorMacIds) {
            bw1.write(errorMacId + "\n");
        }
        bw1.flush();
        bw1.close();
    }

    public static void main(String[] args) throws IOException, ParseException {
        String folder_path = "/Users/xyh/Documents/Bluetooth/Bluetooth-visualization/Data/input/raw";
        String vertex_path = "/Users/xyh/Documents/Bluetooth/Bluetooth-visualization/Data/input/vertices_Brisbane.txt";
        String edge_Path = "/Users/xyh/Documents/Bluetooth/Bluetooth-visualization/Data/input/edges_Brisbane.txt";
        String station_path = "/Users/xyh/Documents/Bluetooth/Bluetooth-visualization/Data/input/station_f.txt";
        String errorMacIdsPath = "/Users/xyh/Desktop/statistics/errorIds.txt";
        String pathToWrite = "/Users/xyh/Desktop/statistics/report_speed_considered_redundant_point_remained.txt";
        String samplingRatePath1 = "/Users/xyh/Desktop/sr1.txt";
        String samplingRatePath2 = "/Users/xyh/Desktop/sr2.txt";

        String gapNDist = "/Users/xyh/Desktop/statistics/gap+distance_minspeed_considered.txt";
        String trajGapDistStatis = "/Users/xyh/Desktop/statistics/trajec_gap_dist_stats.txt";

        RoadNetwork roadNetwork = new RoadNetwork(edge_Path);
        Map<String, Station> stations = getStations(station_path, roadNetwork);

        List<String> filePaths = Utilities.readFolder(folder_path);

//        /* Collect all macids that are shared by more than one device */
//        System.out.println("Collect all macids that are shared by more than one device");
//
//        List<String> errorMacIds = new ArrayList<>();
//        BufferedReader br = new BufferedReader(new FileReader(errorMacIdsPath));
//        String line = br.readLine();
//        while (line != null) {
//            errorMacIds.add(line.strip());
//            line = br.readLine();
//        }
//        br.close();
//
//        BufferedWriter bw = new BufferedWriter(new FileWriter(trajGapDistStatis));
//
//        bw.write("mean_gap,median_gap,min_gap,max_gap,std_gap\n");
//        /* Preprocess trajectory data */
//        System.out.println("Preprocess trajectory data");
//        Map<String, double[]> report = new HashMap<>();
//        for (String filePath : filePaths) {
//            System.out.println(filePath);
//            Map<String, List<observations.TrajectoryPoint>> oneDayRaw = parseRawData(filePath, stations);
//            Map.Entry<Integer, Map<String, List<List<observations.TrajectoryPoint>>>> countToCleanedDataOneDay = trajectoryCleaning(oneDayRaw, errorMacIds);
//            double[] stat = summarize(countToCleanedDataOneDay);
//            report.put(filePath, stat);
//
//            for (Map.Entry<String, List<List<observations.TrajectoryPoint>>> entry : countToCleanedDataOneDay.getValue().entrySet()) {
//                for (List<observations.TrajectoryPoint> trajectoryPoints : entry.getValue()) {
//
//                    List<Double> gaps = new ArrayList<>();
//                    List<Double> distances = new ArrayList<>();
//                    for (int i = 1; i < trajectoryPoints.size(); i++) {
//                        double gap = trajectoryPoints.get(i).getEnteredTime() - trajectoryPoints.get(i - 1).getEnteredTime();
//                        double distance = utilities.Utilities.DistanceFunction.pointToPointDistance(
//                                trajectoryPoints.get(i).getLatitude(), trajectoryPoints.get(i).getLongitude(),
//                                trajectoryPoints.get(i - 1).getLatitude(), trajectoryPoints.get(i - 1).getLongitude());
////                        bw.write(gap + "," + distance + "\n");
//
//                        gaps.add(gap);
//                        distances.add(distance);
//                    }
//
//                    bw.write(utilities.Utilities.mean(gaps) + "," + utilities.Utilities.median(gaps) + "," + utilities.Utilities.min(gaps) + ","
//                            + utilities.Utilities.max(gaps) + "," + utilities.Utilities.std(gaps) + utilities.Utilities.mean(distances) + "," +
//                            utilities.Utilities.median(distances) + "," + utilities.Utilities.min(distances) + ","
//                            + utilities.Utilities.max(distances) + "," + utilities.Utilities.std(distances) + "\n");
//                }
//            }
//        }
//
//        bw.flush();
//        bw.close();
//
//        analysis.Preprocessing.writeStat(pathToWrite, report);

        /* Write data to file */
//        writeStat(pathToWrite, report);

//        int total = 0;
//        int overlapping = 0;
//
//        for (String filePath : filePaths) {
//            Map<String, List<observations.TrajectoryPoint>> data = analysis.Preprocessing.parseRawData(filePath,stations);
//            int[] cnt =analysis.Preprocessing.countOverlapping(data);
//            total += cnt[0];
//            overlapping += cnt[1];
//        }
//        System.out.println(total);
//        System.out.println(overlapping);

//        String rawGaps = "/Users/xyh/Desktop/statistics/traces/raw_gaps.txt";
//        String rawDists = "/Users/xyh/Desktop/statistics/traces/raw_dists.txt";
//        String dayNum = "/Users/xyh/Desktop/statistics/traces/day_num.txt";
//        String macIdNum = "/Users/xyh/Desktop/statistics/traces/macIdNum.txt";
//        String speeds = "/Users/xyh/Desktop/statistics/traces/speeds.txt";
//        String seqLen = "/Users/xyh/Desktop/statistics/traces/seqLen.txt";
//
//        BufferedWriter bw1 = new BufferedWriter(new FileWriter(rawGaps));
//        bw1.write("gaps\n");
//        BufferedWriter bw2 = new BufferedWriter(new FileWriter(rawDists));
//        bw2.write("dist\n");
//        BufferedWriter bw3 = new BufferedWriter(new FileWriter(dayNum));
//        bw3.write("date,num\n");
//        BufferedWriter bw4 = new BufferedWriter(new FileWriter(macIdNum));
//        bw4.write("num\n");
//
//        BufferedWriter bw5 = new BufferedWriter(new FileWriter(speeds));
//        bw5.write("speed\n");
//
//        BufferedWriter bw6 = new BufferedWriter(new FileWriter(seqLen));
//        bw6.write("length\n");
//
//        Map<String, Integer> dayToObsNumber = new HashMap<>();
//        Map<String, Integer> macIdToObsNumb = new HashMap<>();
        String traces = "/Users/xyh/Desktop/statistics/traces.txt";
        BufferedWriter bw = new BufferedWriter(new FileWriter(traces));

        for (String filePath : filePaths) {
            System.out.println(filePath);
            Map<String, List<Reading>> oneDayRaw = parseRawData(filePath, stations);
            int totalObsNum = 0;
            for (Map.Entry<String, List<Reading>> entry : oneDayRaw.entrySet()) {
                List<Reading> trajectoryPoints = entry.getValue();
                totalObsNum += trajectoryPoints.size();
//                bw6.write(trajectoryPoints.size() + "\n");
//                if (macIdToObsNumb.get(entry.getKey()) == null) {
//                    macIdToObsNumb.put(entry.getKey(), trajectoryPoints.size());
//                } else {
//                    int num = macIdToObsNumb.get(entry.getKey());
//                    macIdToObsNumb.put(entry.getKey(), num + trajectoryPoints.size());
//                }
                for (int i = 1; i < trajectoryPoints.size(); i++) {
                    double gap = trajectoryPoints.get(i).getEnteredTime() - trajectoryPoints.get(i - 1).getEnteredTime();
                    double distance = utilities.DistanceFunction.pointToPointDistance(
                            trajectoryPoints.get(i).getLat(), trajectoryPoints.get(i).getLon(),
                            trajectoryPoints.get(i - 1).getLat(), trajectoryPoints.get(i - 1).getLon());
//                    bw1.write(Double.toString(gap) + "\n");
//                    bw2.write(Double.toString(distance) + "\n");
//
//                    if (gap > 0) {
//                        bw5.write(Double.toString(distance / gap * 3600) + "\n");
//                    }
                }
//                dayToObsNumber.put(filePath, totalObsNum);
            }
        }

//        bw1.flush();
//        bw1.close();
//        bw2.flush();
//        bw2.close();
//
//        for (Integer value : macIdToObsNumb.values()) {
//            bw4.write(Integer.toString(value) + "\n");
//        }
//        bw4.flush();
//        bw4.close();
//
//        for (Map.Entry<String, Integer> stringIntegerEntry : dayToObsNumber.entrySet()) {
//            bw3.write(stringIntegerEntry.getKey() + "," + Integer.toString(stringIntegerEntry.getValue()) + "\n");
//        }
//        bw3.flush();
//        bw3.close();
//
//
//        bw5.flush();
//        bw6.flush();
//        bw5.close();
//        bw6.close();

        Map<String, Integer> bmsObs = new HashMap<>();

        for (String filePath : filePaths) {
            BufferedReader br = new BufferedReader(new FileReader(filePath));
            String line = br.readLine();
            while (line != null) {
                String areaNum = Arrays.asList(line.split(",")).get(3);
                if (bmsObs.containsKey(areaNum)) {
                    int num = bmsObs.get(areaNum);
                    bmsObs.put(areaNum, num + 1);
                } else {
                    bmsObs.put(areaNum, 1);
                }

                line = br.readLine();
            }
        }

        String stationCnt = "/Users/xyh/Desktop/statistics/traces/station_cnt.txt";
        BufferedWriter bw7 = new BufferedWriter(new FileWriter(stationCnt));
        bw7.write("areaNum,Cnt\n");
        for (Map.Entry<String, Integer> stringIntegerEntry : bmsObs.entrySet()) {
            bw7.write(stringIntegerEntry.getKey() + "," + stringIntegerEntry.getValue() + "\n");
        }
        bw7.flush();
        bw7.close();
    }
}
