package hmm;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Manages StateCandidates at a same timestamp
 */
public class StateMemory {
    private Map<String, StateCandidate> stateCandidates = new HashMap<>();
    private StateSample sample;
    private StateCandidate filtProbCandidate = null; // the candidate with the largest filter probability
    private String id; // index of this state

    public StateMemory(Set<StateCandidate> stateCandidates, StateSample stateSample, int index) {
        for (StateCandidate stateCandidate : stateCandidates) {
            this.stateCandidates.put(stateCandidate.getId(), stateCandidate);
        }
        this.id = Integer.toString(index);
        for (StateCandidate candidate : stateCandidates) {
            if (filtProbCandidate == null || filtProbCandidate.getFiltProb() < candidate.getFiltProb()) {
                filtProbCandidate = candidate;
            }
        }
        this.sample = stateSample;
    }

    public Map<String, StateCandidate> getStateCandidates() {
        return this.stateCandidates;
    }

    public StateSample getSample() {
        return this.sample;
    }

    public StateCandidate getFiltProbCandidate() {
        return filtProbCandidate;
    }

    public String getId() {
        return id;
    }
}
