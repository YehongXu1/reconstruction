package hmm;

import analysis.Preprocessing;
import index.RoadNetwork;
import index.RoutingGraph;
import index.Station;
import observations.Trace;
import spatialObjects.Coordinate;
import spatialObjects.PointMatch;
import utilities.*;
import index.SpatialIndex;
import observations.Reading;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.text.ParseException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;


public class SimpleHMMMatching implements Serializable {
    private final RoadNetwork roadMap;
    private final RoutingGraph routingGraph;
    private final SpatialIndex rtree;
    private HMMProbabilities hmmProbabilities;
    private double candidateRange;
    //    private double dijkstraDist;
    private long maxWaitingTime;
    private double gamma;
    private double turnWeight;
    private String hmmMethod;

    public SimpleHMMMatching(RoadNetwork roadMap, double sigma, double beta, String hmmMethod, double candidateRange) {
        this.roadMap = roadMap;
        this.routingGraph = new RoutingGraph(roadMap);
        this.rtree = new SpatialIndex(roadMap);
//        double sigma = property.getPropertyDouble("algorithm.mapmatching.Sigma");
//        double beta = property.getPropertyDouble("algorithm.mapmatching.hmm.Beta");
//        gamma = property.getPropertyDouble("algorithm.mapmatching.hmm.Eddy.Gamma");
        this.hmmMethod = hmmMethod;
//        turnWeight = property.getPropertyDouble("algorithm.mapmatching.hmm.turnWeight");
        this.hmmProbabilities = new HMMProbabilities(sigma, beta);
        this.candidateRange = candidateRange;
//        this.dijkstraDist = property.getPropertyDouble("algorithm.mapmatching.wgt.DijkstraThreshold");
//        this.maxWaitingTime = property.getPropertyLong("algorithm.mapmatching.WindowSize");
    }

    /**
     * Gets transitions and its transition probabilities for each pair of state candidates t and t-1
     *
     * @param prevMemory StateMemory object of predecessor state candidate
     * @param candidates Tuple of a set of state candidate at t and its respective measurement sample.
     * @return Maps each predecessor state candidate at t-1 to all state candidates at t.
     * All transitions from t-1 to t and its transition probability, or null if there no transition.
     */
    private Map<String, Map<String, Pair<StateTransition, Double>>> transitions(
            StateMemory prevMemory, Pair<StateSample, Set<StateCandidate>> candidates) {

        StateSample sample = candidates._1();
        StateSample previous = prevMemory.getSample();
        double linearDist = DistanceFunction.pointToPointDistance(sample.lat(), sample.lon(), previous.lat(), previous.lon());

        final List<PointMatch> targets = new LinkedList<>();
        for (StateCandidate candidate : candidates._2()) {
            targets.add(candidate.getPointMatch());
        }

        final Map<String, Map<String, Pair<StateTransition, Double>>> transitions = new ConcurrentHashMap<>();

        for (StateCandidate predecessor : prevMemory.getStateCandidates().values()) {
            Map<String, Pair<StateTransition, Double>> result = new HashMap<>();
            double timeDiff = sample.getTime() - previous.getTime();
            double maxDistance = linearDist * 8;
            List<Triplet<PointMatch, Double, List<String>>> shortestPath = Utilities.getShortestPaths(
                    routingGraph, targets, predecessor.getPointMatch(), new Coordinate<>(sample.lat(), sample.lon()), maxDistance);
            //List<Triplet<PointMatch, Double, List<String>>> shortestPath = utilities.Utilities.getShortestPaths(
            //                    routingGraph, targets, predecessor.getPointMatch(), dijkstraDist);

            Map<PointMatch, Pair<Double, List<String>>> map = new HashMap<>();
            for (Triplet<PointMatch, Double, List<String>> triplet : shortestPath) {
                map.put(triplet._1(), new Pair<>(triplet._2(), triplet._3()));
            }

            for (StateCandidate candidate : candidates._2()) {
                if (map.containsKey(candidate.getPointMatch())) {
                    // the predecessor is able to reach the candidate
                    double distance = map.get(candidate.getPointMatch())._1();
                    double transition = hmmProbabilities.transitionProbability(distance, linearDist, timeDiff);
                    result.put(candidate.getId(),
                            new Pair<>(new StateTransition(map.get(candidate.getPointMatch())._2()), transition));
                }
            }
            transitions.put(predecessor.getId(), result);
        }
        return transitions;
    }


    /**
     * Gets state vector, which is a StateMemory objects and with its emission
     * probability.
     *
     * @param sample current sample
     * @return Set of tuples consisting of a {@link StateCandidate} and its emission probability.
     */
    private Set<StateCandidate> getNeighbourPoints(StateSample sample, int sampleIndex) {

        List<PointMatch> neighbourPms = this.rtree.searchNeighbours(sample.getSampleMeasurement(), candidateRange);
        Set<StateCandidate> candidates = new LinkedHashSet<>();
//        for (PointMatch neighbourPm : neighbourPms) {
        for (PointMatch neighbourPm : neighbourPms) {
            StateCandidate candidate = new StateCandidate(neighbourPm, sample,sampleIndex);
            double dz = DistanceFunction.pointToPointDistance(neighbourPm.lat(), neighbourPm.lon(), sample.lat(), sample.lon());
            candidate.setEmiProb(hmmProbabilities.emissionProbability(dz));
            candidates.add(candidate);
        }
        return candidates;
    }


    /**
     * Executes Hidden Markov Model (HMM) filter iteration that determines for a given measurement
     * sample (a StateSample object) and of a predecessor state vector, which is a set of StateCandidate objects,
     * a state vector with filter and sequence probabilities set.
     * <p>
     * Note: The set of state candidates is allowed to be empty.
     * This is either the initial case or an HMM break occurred, which is no state candidates representing
     * the measurement sample could be found.
     *
     * @param prevStateMemory prevStateMemory, may be empty
     * @param sample          current sample
     * @return StateMemory    which may be empty if an HMM break occurred.
     */
    public StateMemory execute(StateMemory prevStateMemory, StateSample sample, int sampleIndex) {
        Set<StateCandidate> predecessors = new HashSet<>();
        /* prevStateMemory is null if initial MM */
        if (prevStateMemory != null) {
            predecessors = new LinkedHashSet<>(prevStateMemory.getStateCandidates().values());
        }

        Set<StateCandidate> stateCandidates = new HashSet<>();

        /* Get neighbouring points to this sample. If none, return empty an empty StateMemory object */
        Set<StateCandidate> neighbourPoints = getNeighbourPoints(sample, sampleIndex);
        if (neighbourPoints.isEmpty()) return new StateMemory(stateCandidates, sample,sampleIndex);

        double normSum = 0;

        if (!predecessors.isEmpty()) {

            Map<String, Map<String, Pair<StateTransition, Double>>> transitions =
                    transitions(prevStateMemory, new Pair<>(sample, neighbourPoints));

            /* Assign the most likely predecessor for each neighbouring point */
            for (StateCandidate neighbourPoint : neighbourPoints) {
//                if (neighbourPoint.getId().split("_")[0].equals("47410563|1449286039") ||
//                neighbourPoint.getId().split("_")[0].equals("2580429659|1546620203")){
//                    System.out.println();
//                }
                double maxSeqProb = -1; // seqProb used to find backTrackingPointer

                /* Find a predecessor that maximize filtProb for the neighbouring point */
                for (StateCandidate predecessor : predecessors) {
                    Pair<StateTransition, Double> transition = transitions.get(predecessor.getId()).get(neighbourPoint.getId());
//                    if (predecessor.getId().split("_")[0].equals("2580429659|1546620203")) {
//                        System.out.println();
//                    }
                    if (transition == null || transition._2() == 0) {
                        continue;
                    }
                    double seqProb = predecessor.getFiltProb() * transition._2();
                    if (seqProb > maxSeqProb) {
                        neighbourPoint.setPredecessor(predecessor);
                        neighbourPoint.setTransition(transition._1());
                        maxSeqProb = seqProb;
                    }
                }

                /* A neighbouring point is a valid candidate for this sample only if it connects to a predecessor */
                if (neighbourPoint.getPredecessor() != null) {
                    neighbourPoint.setFiltProb(maxSeqProb * neighbourPoint.getEmiProb());
                    stateCandidates.add(neighbourPoint);
                    normSum += neighbourPoint.getFiltProb();
                }

            }
        }

        /* stateCandidates is empty if none of the neighbouring point connect to a predecessor (i.e. HMM break)*/
        /* predecessors is empty if HMM break happened in the previous (last) state */
        if (stateCandidates.isEmpty() || predecessors.isEmpty()) {
            // either because initial map-matching or matching break
            for (StateCandidate candidate : neighbourPoints) {
                if (candidate.getEmiProb() == 0) {
                    continue;
                }
                normSum += candidate.getEmiProb();
                candidate.setFiltProb(candidate.getEmiProb());
                stateCandidates.add(candidate);

            }
        }

        for (StateCandidate candidate : stateCandidates) {
            candidate.setFiltProb(candidate.getFiltProb() / normSum);
        }
        return new StateMemory(stateCandidates, sample,sampleIndex);
    }

    private Pair<List<Double>, Pair<List<PointMatch>, List<String>>> pullMatchResult(SequenceMemory sequence, Trace trajectory) {
        if (trajectory.size() == 0) {
            throw new RuntimeException("Invalid trajectory");
        }
        List<StateSample> samples = new LinkedList<>();
        for (int i = 0; i < trajectory.getTrace().size(); i++) {
            samples.add(new StateSample(trajectory.getTrace().get(i).getFixedPosition(), trajectory.getTrace().get(i).getEnteredTime()));
        }

        samples.sort((left, right) -> (int) (left.getTime() - right.getTime()));

        Map<String, StateCandidate> optimalCandidateSeq = new HashMap<>(); // key is state id
        // calculate latency
        List<Double> latency = new ArrayList<>();
        // Record states have been matched
        Set<String> preStatesRecord = new HashSet<>();

        for (int sampleIndex = 0; sampleIndex < samples.size(); sampleIndex++) {
            StateSample sample = samples.get(sampleIndex);
            StateMemory vector = execute(sequence.lastStateMemory(), sample, sampleIndex);
            // ignore a gps point which doesn't have candidate point
            if (!vector.getStateCandidates().isEmpty()) {
                sequence.updateFixed(vector, sample, optimalCandidateSeq); // offline mode
            } else {
                // the sample got no neighbouring point on road network
                optimalCandidateSeq.put(Integer.toString(sampleIndex), new StateCandidate());
            }
        }

        List<StateMemory> stateMemories = sequence.getStateMemoryVector();
        if (stateMemories.size() > 0) {
            // both goh and fixed-window use this method to get last states
            sequence.reverse(optimalCandidateSeq, sequence.getStateMemoryVector().size() - 1);
        }

        List<String> routeMatchResult = new LinkedList<>();
        List<PointMatch> pointMatchResult = new LinkedList<>();

        for (int i = 0; i < trajectory.size(); i++) {
            Reading trajectoryPoint = trajectory.get(i);
            String id = Integer.toString(i);
            if (optimalCandidateSeq.get(id).getPointMatch() != null) {
                StateCandidate candidate = optimalCandidateSeq.get(id);
                StateSample sample = candidate.getStateSample();
                if (candidate.getId().charAt(0) == '_') continue;
                Coordinate<Double, Double> point = DistanceFunction.closestPointOnSegment(
                        candidate.getPointMatch().getMatchedSegment().getStartNode(),
                        candidate.getPointMatch().getMatchedSegment().getEndNode(), sample.getSampleMeasurement());
                PointMatch pm = new PointMatch(point, candidate.getPointMatch().getMatchedSegment(), candidate.getId());
                pointMatchResult.add(pm);
                routeMatchResult.addAll(candidate.getTransition().getRoute());
            } else {
                pointMatchResult.add(new PointMatch());
            }
        }
        return new Pair<>(latency, new Pair<>(pointMatchResult, routeMatchResult));
    }

    /**
     * Matches a full sequence of samples, StateSample objects and returns state
     * representation of the full matching which is a SequenceMemory object. Output the map-matching result eventually.
     *
     * @param trace Sequence of samples, StateSample objects.
     * @return State representation of the full matching which is a SequenceMemory object.
     */
    public Triplet<String, List<PointMatch>, List<String>> offlineMatching(Trace trace) {
        if (trace == null) return null;
        Pair<List<PointMatch>, List<String>> pointToRouteResult =
                pullMatchResult(new SequenceMemory(), trace)._2();

        List<PointMatch> pointMatchResult = pointToRouteResult._1();
        List<String> routeMatchResult = pointToRouteResult._2();
        return new Triplet<>(trace.getId(), pointMatchResult, routeMatchResult);
    }

    public static void main(String[] args) throws IOException, ParseException {

        String folder_path = "/Users/xyh/Documents/Bluetooth/Bluetooth-visualization/Data/input/raw";
        String vertex_path = "/Users/xyh/Documents/Bluetooth/Bluetooth-visualization/Data/input/vertices_Brisbane.txt";
        String edge_Path = "/Users/xyh/Documents/Bluetooth/data/input/map/edges_Brisbane.txt";
        String stationPath = "/Users/xyh/Documents/Bluetooth/Bluetooth-visualization/Data/input/station.txt";
        String errorMacIdsPath = "/Users/xyh/Desktop/statistics/errorIds.txt";
        String pathToWrite = "/Users/xyh/Desktop/statistics/report_speed_considered_redundant_point_remained.txt";
        String samplingRatePath1 = "/Users/xyh/Desktop/sr1.txt";
        String samplingRatePath2 = "/Users/xyh/Desktop/sr2.txt";

        String gapNDist = "/Users/xyh/Desktop/statistics/gap+distance_minspeed_considered.txt";
        String trajGapDistStatis = "/Users/xyh/Desktop/statistics/trajec_gap_dist_stats.txt";

        RoadNetwork roadNetwork = new RoadNetwork(edge_Path);
        Map<String, Station> stations = Preprocessing.getStations(stationPath, roadNetwork);

//        List<Reading> points = new ArrayList<>();

//        points.add(new Reading(8134,8174, new Coordinate<>(-27.48511, 153.04017)));
//        points.add(new Reading(8215,8216, new Coordinate<>(-27.47883, 153.04145)));
//        points.add(new Reading(8548,8568,new Coordinate<>(-27.44252, 153.03019)));
//        points.add(new Reading(8599, 8638, new Coordinate<>(-27.43805, 153.03101)));
//        points.add(new Reading(8655, 8695, new Coordinate<>(-27.43753, 153.02706)));
//        points.add(new Reading(9515, 9516, new Coordinate<>(-27.43702, 153.02402)));

//        points.add(new Reading(1,2, new Coordinate<>(-27.48511, 153.04017)));
//        points.add(new Reading(3,4, new Coordinate<>(-27.47883, 153.04145)));
//        points.add(new Reading(5,6,new Coordinate<>(-27.44252, 153.03019)));
//        points.add(new Reading(7, 8, new Coordinate<>(-27.43805, 153.03101)));
//        points.add(new Reading(9, 10, new Coordinate<>(-27.43753, 153.02706)));
//        points.add(new Reading(11, 12, new Coordinate<>(-27.43702, 153.02402)));

//        points.add(new Reading(11, 12, new Coordinate<>(-27.47593, 153.14066)));
//        points.add(new Reading(13, 14, new Coordinate<>(-27.47622, 153.13417)));
//        points.add(new Reading(13, 16, new Coordinate<>(-27.47466, 153.12916)));
//        points.add(new Reading(13, 18, new Coordinate<>(-27.47467, 153.12789)));
//        points.add(new Reading(19, 20, new Coordinate<>(-27.47456, 153.1253)));
//        points.add(new Reading(21, 22, new Coordinate<>(27.47451, 153.12008)));
//        points.add(new Reading(23, 24, new Coordinate<>(-27.47446, 153.11902)));
//        points.add(new Reading(25, 26, new Coordinate<>(-27.4602, 153.03553)));
//        points.add(new Reading(27, 28, new Coordinate<>(-27.54488, 153.11794)));
//        points.add(new Reading(29, 30, new Coordinate<>(-27.58179, 153.10332)));
//        points.add(new Reading(31, 32, new Coordinate<>(-27.59229, 153.10997)));
//        Trace trace = new Trace("1", points);
//        SimpleHMMMatching simpleHMMMatching = new SimpleHMMMatching(roadNetwork, 4.07, 0.008, "off", 0.05);
//        Triplet<String, List<PointMatch>, List<String>> result = simpleHMMMatching.offlineMatching(trace);
//        StringBuilder stringBuilder = new StringBuilder();
//        for (String s : result._3()) {
//            Edge edge = roadNetwork.getEdges().get(s);
//            stringBuilder.append(edge.toString());
//        }
//        String matchedPath = stringBuilder.toString();
//        System.out.println(matchedPath);

        List<String> filePaths = Utilities.readFolder(folder_path);

        for (String filePath : filePaths) {
            Map<String, List<Reading>> traces = Preprocessing.parseRawData(filePath, stations);
            BufferedWriter bf = new BufferedWriter(new FileWriter("/Users/xyh/Desktop/matched_result.txt"));
//            BufferedWriter bf1 = new BufferedWriter(new FileWriter("/Users/xyh/Desktop/matched_result_newTrace.txt"));

            int j = 0;
            for (Map.Entry<String, List<Reading>> macIdToTracePoints : traces.entrySet()) {
                List<Reading> points = macIdToTracePoints.getValue();

                System.out.println(j);
                List<List<Reading>> indiTrips = Preprocessing.trajectoryIdentification(points);

                for (int i = 0; i < indiTrips.size(); i++) {
                    List<Reading> trip = indiTrips.get(i);
//                    Pair<List<Reading>, List<Pair<Integer, Integer>>> pair = OverlappingAnalysis.detectOverlappingRegion2(trip, 2);
//
//                    if (trip.size() == pair._1().size()) {
//                        System.out.println("same");
//                        continue;
//                    }
                    Trace trace = new Trace(macIdToTracePoints.getKey() + "_" + i, trip);

                    StringBuilder sb = new StringBuilder();
                    for (Reading t : trace.getTrace()) {
                        sb.append(t.getCoord().toString());
                        sb.append(" ");
                        sb.append(t.getEnteredTime());
                        sb.append(" ");
                        sb.append(t.getDeparturedTime());
                        sb.append(",");
                    }
                    String path = sb.toString();
                    System.out.println(path);

//                    SimpleHMMMatching simpleHMMMatching = new SimpleHMMMatching(roadNetwork, 4, 0.008, "off", 0.05);
//
//                    Triplet<String, List<PointMatch>, List<String>> results = simpleHMMMatching.offlineMatching(trace);
//                    StringBuilder stringBuilder = new StringBuilder();
//                    for (String s : results._3()) {
//                        Edge edge = roadNetwork.getEdges().get(s);
//                        stringBuilder.append(s);
//                        stringBuilder.append(" ");
//                     }
//                    String matchedPath = stringBuilder.toString();
//
//
//                    Trace newTrace = new Trace(macIdToTracePoints.getKey() + "_" + i, pair._1());
//                    StringBuilder sb2 = new StringBuilder();
//                    for (Reading t : newTrace.getTrace()) {
//                        sb2.append(t.getStationPoint().getLocation().toString());
//                        sb2.append(" ");
//                        sb2.append(t.getEnteredTime());
//                        sb2.append(" ");
//                        sb2.append(t.getDeparturedTime());
//                        sb2.append(",");
//                    }
//                    String path2 = sb2.toString();
//
//                    Triplet<String, List<PointMatch>, List<String>> newResults = simpleHMMMatching.offlineMatching(newTrace);
//                    StringBuilder stringBuilder2 = new StringBuilder();
//                    for (String s : newResults._3()) {
//                        Edge edge = roadNetwork.getEdges().get(s);
//                        stringBuilder2.append(s);
//                        stringBuilder2.append(" ");
//                        stringBuilder2.append(edge.toString());
//                    }
//                    String matchedPath2 = stringBuilder2.toString();
//                    if (!path.equals(path2)) {
//                        System.out.println(newTrace.size() + " " + trace.size());
//                        bf.write(path + "&" + matchedPath + "\n");
//                        bf1.write(path2 + "&" + matchedPath2 + "\n");
//                    }
                }
            }
            bf.flush();
//            bf1.flush();
            bf.close();
//            bf1.close();
        }
    }
}
