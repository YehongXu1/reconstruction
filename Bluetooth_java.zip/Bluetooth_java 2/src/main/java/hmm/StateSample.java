package hmm;

import spatialObjects.Coordinate;

import java.util.Objects;

public class StateSample {

    private Coordinate<Double, Double> sampleMeasurement;
    private double sampleTime = -1;


    public StateSample(Coordinate<Double, Double> point, double time) {
        this.sampleMeasurement = point;
        this.sampleTime = time;
    }

    public double lat() {
        return sampleMeasurement.getLat();
    }

    public double lon() {
        return this.sampleMeasurement.getLon();
    }

    public Coordinate<Double, Double> getSampleMeasurement() {
        return sampleMeasurement;
    }

    public double getTime() {
        return sampleTime;
    }

//    public double getHeading() {
//        return heading;
//    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        StateSample that = (StateSample) o;

        return sampleTime == that.getTime()
//                && heading == that.getHeading()
                && sampleMeasurement.equals(that.getSampleMeasurement());
    }

    @Override
    public int hashCode() {
        return Objects.hash(sampleMeasurement, sampleTime);
    }
}
