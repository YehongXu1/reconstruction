import com.github.davidmoten.rtree.RTree;
import com.github.davidmoten.rtree.geometry.Geometries;
import com.github.davidmoten.rtree.geometry.Geometry;
import groovy.json.JsonOutput;
import observations.Reading;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;


public class test {

    private static class Point {
        private int id;
        private int st;
        private int end;

        private Point(int id, int st, int end) {
            this.id = id;
            this.end = end;
            this.st = st;
        }

        private int getSt() {
            return st;
        }

        private int getEnd() {
            return end;
        }

        private int getId() {
            return id;
        }
    }

    public static void main(String[] args) {
        String abc = "/Users/xyh/Documents/Bluetooth/Bluetooth-visualization/Data/input/raw/2016-06-20.csv";
//        String date = Arrays.asList(Arrays.asList(abc.split("\\.")).get(1).split("/")).get(3);
//        System.out.println(date);
        System.out.println();

        double x = 2.0;
        double d = 1.0;

        double degree = Math.toDegrees(Math.acos(d / x));
        System.out.println(x * Math.sin(Math.toRadians(degree)));
    }
}
