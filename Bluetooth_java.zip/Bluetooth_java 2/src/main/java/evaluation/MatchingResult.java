package evaluation;

import observations.Trace;
import spatialObjects.PointMatch;

import java.util.ArrayList;
import java.util.List;

public class MatchingResult {
    private Trace trace;
    private List<PointMatch> pointMatchResult;
    private List<String> routeMatchResult;

    public MatchingResult(Trace trace, List<PointMatch> pointMatchResult, List<String> routeMatchResult) {

        if (pointMatchResult == null || pointMatchResult.isEmpty())
            this.pointMatchResult = new ArrayList<>();
        else {
//            for (PointMatch pointMatch : pointMatchResult) {    // remove the trailing road series number.
//                pointMatch.setRoadID(pointMatch.getRoadID().contains("|") ? pointMatch.getRoadID().substring(0,
//                        pointMatch.getRoadID().lastIndexOf("|")) : pointMatch.getRoadID());
//            }
            this.pointMatchResult = pointMatchResult;
        }

        if (routeMatchResult == null || routeMatchResult.isEmpty())
            this.routeMatchResult = new ArrayList<>();
        else
            this.routeMatchResult = routeMatchResult;
    }

    public Trace getTrace(){
        return trace;
    }

    public List<PointMatch> getPointMatchResult(){
        return pointMatchResult;
    }

    public List<String> getRouteMatchResult() {
        return routeMatchResult;
    }
}
