package evaluation;

import index.RoadNetwork;
import observations.Trace;
import utilities.DistanceFunction;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.util.jar.JarOutputStream;

public class Evaluation {

    public static double lengthIndex(MatchingResult matchingResult, RoadNetwork roadNetwork) {
        Trace trace = matchingResult.getTrace();
        List<String> route = matchingResult.getRouteMatchResult();
        double traceLen = 0;
        double matchLen = 0;

        for (int i = 1; i < trace.getTrace().size(); i++) {
            traceLen += DistanceFunction.pointToPointDistance(
                    trace.getTrace().get(i).getCoord(), trace.getTrace().get(i - 1).getCoord());

        }

        String edgeId = route.get(0);
        matchLen += roadNetwork.getEdges().get(edgeId).getLengh();
        for (int i = 1; i < route.size(); i++) {
            if (!edgeId.equals(route.get(i))) {
                matchLen += roadNetwork.getEdges().get(route.get(i)).getLengh();
            }
        }

        return matchLen / traceLen;
    }

    public static double precision(List<String> matchedResultList, List<String> gtList) {
        int correctGuess = 0;

        Set<String> matchedResult = new HashSet<>(matchedResultList);
        Set<String> gt = new HashSet<>(gtList);

        for (String s : matchedResult) {
            if (gt.contains(s)) correctGuess += 1;
        }
        return (double) correctGuess / (double) matchedResult.size();
    }

    public static double recall(List<String> matchedResultList, List<String> gtList) {
        int correctGuess = 0;

        Set<String> matchedResult = new HashSet<>(matchedResultList);
        Set<String> gt = new HashSet<>(gtList);

        for (String s : matchedResult) {
            if (gt.contains(s)) correctGuess += 1;
        }
        return (double) correctGuess / (double) gt.size();
    }

    public static double f1Score(List<String> matchedResultList, List<String> gtList) {

        double precision = precision(matchedResultList, gtList);
        double recall = recall(matchedResultList, gtList);

        if (precision == 0 || recall == 0) return 0;
        return 2 * precision * recall / (recall + precision);
    }

    public static double accuracy(List<String> matchedResultList, List<String> gtList) {
        Set<String> matchedResult = new HashSet<>(matchedResultList);
        Set<String> gt = new HashSet<>(gtList);

        List<String> edges = new ArrayList<>(matchedResult);
        for (String s : gt) {
            if (edges.contains(s)) continue;
            edges.add(s);
        }

        int correctGuess = 0;
        for (String s : matchedResult) {
            if (gt.contains(s)) correctGuess += 1;
        }
        return (double) correctGuess / (double) edges.size();
    }

    public static void main(String[] args) throws IOException {
        String results = "/Users/xyh/Desktop/experimental results/results.txt";
        String gt = "/Users/xyh/Desktop/experimental results/ground_truths_edges.txt";

        BufferedReader brRe = new BufferedReader(new FileReader(results));
        BufferedReader brGt = new BufferedReader(new FileReader(gt));

        List<String>[] matchedResults = new ArrayList[315];
        String matchedLine = brRe.readLine();

        int ftNum = 0;
        while (matchedLine != null) {
            List<String> matchedResult = new ArrayList<>();

            String[] matchedResultRaw = matchedLine.split(",&")[1].split(";");

            for (String rs : matchedResultRaw) {
                matchedResult.add(rs.split("\\s")[0]);
            }

            matchedResults[ftNum] = matchedResult;
            ftNum += 1;
            matchedLine = brRe.readLine();
        }

        String gtLine = brGt.readLine();
        String[][] gtsSegments = new String[15][];

        ftNum = 0;
        while (gtLine != null) {

            gtsSegments[ftNum] = gtLine.split(";")[1].split(" ");
            ftNum += 1;
            gtLine = brGt.readLine();
        }

        double[][] scores = new double[21][4];
        for (int ftIdx = 0; ftIdx < 15; ftIdx++) {
            System.out.println("footprint: " + (ftIdx + 1));
            for (int transIdx = 0; transIdx < 21; transIdx++) {
                System.out.println("    acc: " + Evaluation.accuracy(matchedResults[ftIdx * 21 + transIdx], Arrays.asList(gtsSegments[ftIdx])));
                System.out.println("    pre: " + Evaluation.precision(matchedResults[ftIdx * 21 + transIdx], Arrays.asList(gtsSegments[ftIdx])));
                System.out.println("    rec: " + Evaluation.recall(matchedResults[ftIdx * 21 + transIdx], Arrays.asList(gtsSegments[ftIdx])));
                System.out.println("    f1s: " + Evaluation.f1Score(matchedResults[ftIdx * 21 + transIdx], Arrays.asList(gtsSegments[ftIdx])));
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

                scores[transIdx][0] += Evaluation.accuracy(matchedResults[ftIdx * 21 + transIdx], Arrays.asList(gtsSegments[ftIdx]));
                scores[transIdx][1] += Evaluation.precision(matchedResults[ftIdx * 21 + transIdx], Arrays.asList(gtsSegments[ftIdx]));
                scores[transIdx][2] += Evaluation.recall(matchedResults[ftIdx * 21 + transIdx], Arrays.asList(gtsSegments[ftIdx]));
                scores[transIdx][3] += Evaluation.f1Score(matchedResults[ftIdx * 21 + transIdx], Arrays.asList(gtsSegments[ftIdx]));

            }
        }

        for (int j = 0; j < 21; j++) {
            System.out.println("~~~~~~~~~~~~~The " + j + "-th Transformation~~~~~~~~~~~~");
            System.out.println("acc: " + String.format("%.4f", scores[j][0] / 15));
            System.out.println("pre: " + String.format("%.4f", scores[j][1] / 15));
            System.out.println("rec: " + String.format("%.4f", scores[j][2] / 15));
            System.out.println("f1s: " + String.format("%.4f", scores[j][3] / 15));

        }
    }

}
