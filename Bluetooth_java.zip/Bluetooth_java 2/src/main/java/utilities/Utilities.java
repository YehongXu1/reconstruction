package utilities;

import index.RoutingGraph;
import spatialObjects.Coordinate;
import spatialObjects.PointMatch;
import utilities.Pair;
import utilities.Triplet;

import java.io.File;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class Utilities {

    /**
     * Transform string to second
     *
     * @param time
     * @return
     */
    public static long transformToSecond(String time) throws ParseException {
        Date date = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss").parse(time);
        return date.getTime() / 1000;
    }


    /***
     * Retrieve names of all valid files in the specified folder
     *
     * @param folderPath path of the folder
     * @return list of file names
     */
    public static List<String> readFolder(String folderPath) {
        List<String> filePaths = new ArrayList<>();

        File folder = new File(folderPath);
        File[] listOfFiles = folder.listFiles();

        for (File file : listOfFiles) {
            if (file.isFile()) {
                String fileName = file.getName();
                if (fileName.matches("2016-06-\\d{2}.csv")) {
                    String filePath = folderPath + "/" + fileName;
                    filePaths.add(filePath);
                }
            }
        }

        return filePaths;
    }


    public static double max(List<Double> values) {
        double max = Double.MIN_VALUE;
        for (double value : values) {
            if (max < value) max = value;
        }
        return max;
    }

    public static double min(List<Double> values) {
        double min = Double.MAX_VALUE;
        for (double value : values) {
            if (min > value) min = value;
        }
        return min;
    }

    public static double mean(List<Double> values){
        double sum = 0;
        for (double value : values) {
            sum += value;
        }
        return sum/values.size();
    }

    public static double median(List<Double> values) {
        int middle = values.size()/2;
        Collections.sort(values);
        return values.get(middle);
    }

    public static double std(List<Double> values) {
        double mean = mean(values);
        double sum = 0;
        for (double value : values) {
            sum += (value-mean)*(value-mean);
        }
        return Math.sqrt(sum/values.size());
    }

    /**
     * Find the shortest path from a source node to each destination node
     *
     * @param destinations   a set of destination nodes
     * @param source         the source node
     * @param referencePoint
     * @param maxDistance    threshold
     * @return shortest paths List<DestinationPM, shortestPathLength, Path>
     */
    public static List<Triplet<PointMatch, Double, List<String>>> getShortestPaths(
            RoutingGraph routingGraph, List<PointMatch> destinations, PointMatch source,
            Coordinate<Double, Double> referencePoint, double maxDistance) {

        // The graph for Dijkstra shortest distance calculation
        List<Pair<Double, List<String>>> shortestPaths = routingGraph.calculateOneToNAStarSP(source, destinations, referencePoint,
                maxDistance);

        List<Triplet<PointMatch, Double, List<String>>> shortestPathToDestPM = new ArrayList<>();

        for (int i = 0; i < destinations.size(); i++) {
            if (shortestPaths.get(i)._1() != Double.POSITIVE_INFINITY) {
                shortestPathToDestPM.add(new Triplet<>(destinations.get(i), shortestPaths.get(i)._1(), shortestPaths.get(i)._2()));
            }
        }

        return shortestPathToDestPM;
    }

    /**
     * Round 14 decimal places to 7 decimal places
     *
     * @param number 14 decimal_places number
     * @return 5 decimal_places number
     */
    public static double formatDoubles(double number) {
        DecimalFormat df = new DecimalFormat("#.0000000");
        return Double.parseDouble(df.format(number));
    }

    public static Coordinate<Double, Double> formatDoubles(Coordinate<Double, Double> coordinate){
        return new Coordinate<>(formatDoubles(coordinate.getLat()), formatDoubles(coordinate.getLon()));
    }



    public static void main(String[] args) throws ParseException {

        System.out.println(transformToSecond("2016-06-20 00:00:00"));
        System.out.println(transformToSecond("2016-06-20 11:59:54"));
        System.out.println(transformToSecond("2016-06-20 12:00:00"));
        System.out.println(transformToSecond("2016-06-20 23:59:59"));
    }
}
