package utilities;

import spatialObjects.Coordinate;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import static java.lang.Math.*;
import static utilities.Utilities.formatDoubles;

public class DistanceFunction {

    private final static double R = 6378.1370;

    public static double pointToPointDistance(double lat1, double lon1, double lat2, double lon2) {
        double a = Math.sin(toRadians(lat2 - lat1) / 2) * Math.sin(toRadians(lat2 - lat1) / 2) +
                Math.cos(toRadians(lat1)) * Math.cos(toRadians(lat2)) *
                        Math.sin(toRadians(lon2 - lon1) / 2) * Math.sin(toRadians(lon2 - lon1) / 2);

        double c = 2 * atan2(sqrt(a), sqrt(1 - a));

        return R * c;

    }

    public static double pointToPointDistance(Coordinate<Double, Double> c1, Coordinate<Double, Double> c2) {
        return pointToPointDistance(c1.getLat(), c1.getLon(), c2.getLat(), c2.getLon());
    }

    /**
     * Cross-track distance
     * <p>
     * Here, the great-circle path is identified by a start point and an end point – depending on what initial data
     * you’re working from, you can use the formulas above to obtain the relevant distance and bearings.
     *
     * @param lat
     * @param lon
     * @param lat1
     * @param lon1
     * @param lat2
     * @param lon2
     * @return
     */
    public static double pointProjectToSegmentDistance(double lat1, double lon1, double lat2, double lon2, double lat, double lon) {

        double angularDist13 = angularDistance(lat1, lon1, lat, lon);
        double initialBearing13 = toRadians(initialBearing(lat1, lon1, lat, lon));
        double initialBearing12 = toRadians(initialBearing(lat1, lon1, lat2, lon2));

        return abs(asin(sin(angularDist13) * sin(initialBearing13 - initialBearing12)) * R);
    }

    private static double angularDistance(double lat1, double lon1, double lat2, double lon2) {
        return 2 * asin(sqrt(sin(toRadians(lat2 - lat1) / 2) * sin(toRadians(lat2 - lat1) / 2) +
                cos(toRadians(lat1)) * cos(toRadians(lat2)) * sin(toRadians(lon2 - lon1) / 2) * sin(toRadians(lon2 - lon1) / 2)));
    }

    /**
     * Returns the initial bearing from ‘this’ point to destination point.
     *
     * @param {LatLon} point - Latitude/longitude of destination point.
     * @returns {number} Initial bearing in degrees from north (0°..360°).
     * @example const p1 = new LatLon(52.205, 0.119);
     * const p2 = new LatLon(48.857, 2.351);
     * const b1 = p1.initialBearingTo(p2); // 156.2°
     */
    private static double initialBearing(double lat1, double lon1, double lat2, double lon2) {

        double lat1_ = toRadians(lat1);
        double lat2_ = toRadians(lat2);
        double dlon = toRadians(lon2 - lon1);

        double x = Math.cos(lat1_) * Math.sin(lat2_) - Math.sin(lat1_) * Math.cos(lat2_) * Math.cos(dlon);
        double y = Math.sin(dlon) * Math.cos(lat2_);
        double theta = Math.atan2(y, x);

        double bearing = toDegrees(theta);

        return wrap360(bearing);
    }

    public static double directionChange(double lat1, double lon1, double lat2, double lon2, double lat3, double lon3, double lat4, double lon4) {
        double[] vA = {lat1 - lat2, lon1 - lon2};
        double[] vB = {lat3 - lat4, lon3 - lon4};

        double dotProduct = dotProduct(vA, vB);
        double magA = Math.sqrt(dotProduct(vA, vA));
        double magB = Math.sqrt(dotProduct(vB, vB));

        double cos_ = dotProduct / magA / magB;
        if (abs(cos_-1) < 0.0001)
            return 0;

        double angle = Math.acos(cos_);
        double ang_deg = toDegrees(angle)%360;
        return ang_deg >= 180 ? (360 - ang_deg) : ang_deg;
    }

    private static double dotProduct(double[] vA, double[] vB) {
        return vA[0] * vB[0] + vA[1] * vB[1];
    }

    public static double directionChange(Coordinate<Double, Double> a, Coordinate<Double, Double> b, Coordinate<Double, Double> c, Coordinate<Double, Double> d) {
        return directionChange(a.getLat(), a.getLon(), b.getLat(), b.getLon(), c.getLat(), c.getLon(), d.getLat(), d.getLon());
    }

    private static double wrap360(double degrees) {
        if (0 <= degrees && degrees < 360) return degrees; // avoid rounding due to arithmetic ops if within range
        return (degrees % 360 + 360) % 360; // sawtooth wave p:360, a:360
    }


    private static double[] toCartsian(Coordinate<Double, Double> coord) {
        double[] result = new double[3];
        result[0] = R * cos(toRadians(coord.getLat())) * cos(toRadians(coord.getLon()));
        result[1] = R * cos(toRadians(coord.getLat())) * sin(toRadians(coord.getLon()));
        result[2] = R * sin(toRadians(coord.getLat()));
        return result;
    }

    private static Coordinate<Double, Double> fromCartsian(double[] t) {
        double lat = toDegrees(asin(t[2] / R));
        double lon = toDegrees(atan2(t[1], t[0]));

        return new Coordinate<>(formatDoubles(lat), formatDoubles(lon));
    }

    /**
     * @param a
     * @param b
     * @param c
     * @return
     */
    private static Coordinate<Double, Double> nearestPointGreatCircle(Coordinate<Double, Double> a, Coordinate<Double, Double> b, Coordinate<Double, Double> c) {
        double[] a_ = toCartsian(a);
        double[] b_ = toCartsian(b);
        double[] c_ = toCartsian(c);

        double[] G = vectorProduct(a_, b_);
        double[] F = vectorProduct(c_, G);
        double[] t = vectorProduct(G, F);

        double[] t_normalized = normalize(t);
        double[] t_scaled = multiplyByScalar(t_normalized, R);
        return fromCartsian(t_scaled);
    }

    private static double[] normalize(double[] t) {
        double length = Math.sqrt((t[0] * t[0]) + (t[1] * t[1]) + (t[2] * t[2]));
        double[] result = new double[3];
        result[0] = t[0] / length;
        result[1] = t[1] / length;
        result[2] = t[2] / length;
        return result;
    }

    private static double[] multiplyByScalar(double[] normalize, double k) {
        double[] result = new double[3];
        result[0] = normalize[0] * k;
        result[1] = normalize[1] * k;
        result[2] = normalize[2] * k;
        return result;
    }

    private static double[] vectorProduct(double[] a, double[] b) {
        double x = a[1] * b[2] - a[2] * b[1]; // cx = aybz − azby
        double y = a[2] * b[0] - a[0] * b[2]; // cy = azbx − axbz
        double z = a[0] * b[1] - a[1] * b[0]; // cz = axby − aybx

        return new double[]{x, y, z};
    }

    public static Coordinate<Double, Double> closestPointOnSegment(Coordinate<Double, Double> a, Coordinate<Double, Double> b, Coordinate<Double, Double> c) {
        Coordinate<Double, Double> t = nearestPointGreatCircle(a, b, c);
        if (onSegment(a, b, t)) return t;
        double distAC = pointToPointDistance(a.getLat(), a.getLon(), c.getLat(), c.getLon());
        double distBC = pointToPointDistance(b.getLat(), b.getLon(), c.getLat(), c.getLon());

        if (distAC < distBC) return a;
        return b;
    }

    public static Coordinate<Double, Double> locFromPointGivenBnrDist(double clat, double clon, double bearing, double distKm) {
        double lat1 = toRadians(clat);
        double lon1 = toRadians(clon);

        double lat2 = asin(sin(lat1) * cos(distKm / R) + cos(lat1) * sin(distKm / R) * cos(bearing));
        double lon2 = lon1 + atan2(sin(bearing) * sin(distKm / R) * cos(lat1), cos(distKm / R) - sin(lat1) * sin(lat2));

        double lat2_ = toDegrees(lat2);
        double lon2_ = toDegrees(lon2);

        return new Coordinate<>(lat2_, lon2_);
    }


    public static double pointClosestDistanceFromSegment(double lat1, double lon1, double lat2, double lon2, double lat, double lon) {
        Coordinate<Double, Double> a = new Coordinate<>(lat1, lon1);
        Coordinate<Double, Double> b = new Coordinate<>(lat2, lon2);
        Coordinate<Double, Double> c = new Coordinate<>(lat, lon);

        Coordinate<Double, Double> t = nearestPointGreatCircle(a, b, c);
        if (onSegment(a, b, t))
            return pointToPointDistance(t.getLat(), t.getLon(), c.getLat(), c.getLon());

        double distAC = pointToPointDistance(a.getLat(), a.getLon(), c.getLat(), c.getLon());
        double distBC = pointToPointDistance(b.getLat(), b.getLon(), c.getLat(), c.getLon());

        return min(distAC, distBC);
    }

    public static double pointLongestDistanceFromSegment(double lat1, double lon1, double lat2, double lon2, double lat, double lon) {
        Coordinate<Double, Double> a = new Coordinate<>(lat1, lon1);
        Coordinate<Double, Double> b = new Coordinate<>(lat2, lon2);
        Coordinate<Double, Double> c = new Coordinate<>(lat, lon);

        double distAC = pointToPointDistance(a.getLat(), a.getLon(), c.getLat(), c.getLon());
        double distBC = pointToPointDistance(b.getLat(), b.getLon(), c.getLat(), c.getLon());

        return max(distAC, distBC);
    }

    public static double pointLongestDistanceFromSegment(Coordinate<Double, Double> a, Coordinate<Double, Double> b, Coordinate<Double, Double> c) {
        double distAC = pointToPointDistance(a.getLat(), a.getLon(), c.getLat(), c.getLon());
        double distBC = pointToPointDistance(b.getLat(), b.getLon(), c.getLat(), c.getLon());

        return max(distAC, distBC);
    }


    public static boolean onSegment(Coordinate<Double, Double> a, Coordinate<Double, Double> b, Coordinate<Double, Double> t) {
        // should be   return distance(a,t)+distance(b,t)==distance(a,b),
        // but due to rounding errors, we use:
        double distAB = pointToPointDistance(a.getLat(), a.getLon(), b.getLat(), b.getLon());
        double distAT = pointToPointDistance(a.getLat(), a.getLon(), t.getLat(), t.getLon());
        double distBT = pointToPointDistance(b.getLat(), b.getLon(), t.getLat(), t.getLon());

        return abs(distAB - distAT - distBT) < 0.001;
    }

    public static Coordinate<Double, Double> intermediatePoint(double lat1_, double lon1_, double lat2_, double lon2_, double intervalLenKm) {
        double dist = DistanceFunction.pointToPointDistance(lat1_, lon1_, lat2_, lon2_);
        double fraction = intervalLenKm / dist;

        double lat1 = toRadians(lat1_);
        double lat2 = toRadians(lat2_);
        double lng1 = toRadians(lon1_);
        double lng2 = toRadians(lon2_);

        double angular = dist / 6371;

        double a = Math.sin((1 - fraction) * angular) / Math.sin(angular);
        double b = Math.sin(fraction * angular) / Math.sin(angular);

        double x = a * cos(lat1) * cos(lng1) + b * cos(lat2) * cos(lng2);

        double y = a * cos(lat1) * sin(lng1) + b * cos(lat2) * sin(lng2);

        double z = a * sin(lat1) + b * sin(lat2);

        double lat3 = toDegrees(Math.atan2(z, Math.sqrt(x * x + y * y)));
        double lng3 = toDegrees(atan2(y, x));

        return new Coordinate<>(formatDoubles(lat3), formatDoubles(lng3));
    }

    public static List<Coordinate<Double, Double>> findPointOnSegmentGivenDistance(Coordinate<Double, Double> s, Coordinate<Double, Double> e, Coordinate<Double, Double> point, double distance) {
        Coordinate<Double, Double> closestPoint = DistanceFunction.closestPointOnSegment(s, e, point);
        double closestDistance = DistanceFunction.pointToPointDistance(closestPoint, point);

        double distanceFromS = DistanceFunction.pointToPointDistance(closestPoint, s);
        double distanceFromE = DistanceFunction.pointToPointDistance(closestPoint, e);

        List<Coordinate<Double, Double>> potentialPoints = new ArrayList<>();
        if (closestDistance > distance) {
            // should not happen
            System.out.println("Closet distance > distance");
            return potentialPoints;
        }

        if (distance - closestDistance < 0.0005) {
            potentialPoints.add(closestPoint);
            return potentialPoints;
        }

        if (distanceFromS == 0) {
            double leftDistance = distance - closestDistance;
            Coordinate<Double, Double> potentialPoint = DistanceFunction.intermediatePoint(s, e, leftDistance);
            potentialPoints.add(potentialPoint);
        } else if (distanceFromE == 0) {
            double leftDistance = distance - closestDistance;
            Coordinate<Double, Double> potentialPoint = DistanceFunction.intermediatePoint(e, s, leftDistance);
            potentialPoints.add(potentialPoint);
        } else {
            double radius = Math.toRadians(Math.toDegrees(Math.acos(closestDistance / distance)));
            double leftDistance = distance * Math.sin(radius);

            if (leftDistance < distanceFromS) {
                Coordinate<Double, Double> potentialPoint = DistanceFunction.intermediatePoint(closestPoint, s, leftDistance);
                potentialPoints.add(potentialPoint);
            }

            if (leftDistance < distanceFromE) {
                Coordinate<Double, Double> potentialPoint = DistanceFunction.intermediatePoint(closestPoint, e, leftDistance);
                potentialPoints.add(potentialPoint);
            }
        }

        if (potentialPoints.size() == 0) {
            System.out.println("No Potential Point");
        }
        return potentialPoints;
    }

    public static Coordinate<Double, Double> intermediatePoint(Coordinate<Double, Double> s, Coordinate<Double, Double> t, double intervalLenKm) {
        double dist = DistanceFunction.pointToPointDistance(s, t);
        double fraction = intervalLenKm / dist;

        double lat1 = toRadians(s.getLat());
        double lat2 = toRadians(t.getLat());
        double lng1 = toRadians(s.getLon());
        double lng2 = toRadians(t.getLon());

        double angular = dist / R;

        double a = Math.sin((1 - fraction) * angular) / Math.sin(angular);
        double b = Math.sin(fraction * angular) / Math.sin(angular);

        double x = a * cos(lat1) * cos(lng1) + b * cos(lat2) * cos(lng2);

        double y = a * cos(lat1) * sin(lng1) + b * cos(lat2) * sin(lng2);

        double z = a * sin(lat1) + b * sin(lat2);

        double lat3 = toDegrees(Math.atan2(z, Math.sqrt(x * x + y * y)));
        double lng3 = toDegrees(atan2(y, x));

        return new Coordinate<>(formatDoubles(lat3), formatDoubles(lng3));
    }

    public static void main(String[] args) {
        double d = directionChange(-27.45963, 153.03379, -27.46002, 153.03445, -27.46002, 153.03445, -27.46074, 153.03266);
        System.out.println(d);
    }

}
