package utilities;

import spatialObjects.Coordinate;

import java.util.ArrayList;
import java.util.List;

public class RoutingVertex {
    private List<RoutingEdge> outGoingRoutingEdges = new ArrayList<>(); // now we must create outGoingRoutingEdges
    private Coordinate<Double, Double> vertexPoint;
    private int index;

    public List<RoutingEdge> getOutGoingRoutingEdges() {
        return outGoingRoutingEdges;
    }

    public void setOutGoingRoutingEdges(ArrayList<RoutingEdge> outGoingRoutingEdges) {
        this.outGoingRoutingEdges = outGoingRoutingEdges;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public Coordinate<Double, Double> getVertexPoint() {
        return vertexPoint;
    }

    public void setVertexPoint(Coordinate<Double, Double> vertexPoint) {
        this.vertexPoint = vertexPoint;
    }
}
